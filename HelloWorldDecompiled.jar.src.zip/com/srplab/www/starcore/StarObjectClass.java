package com.srplab.www.starcore;

public class StarObjectClass
{
  private StarCoreFactory StarCore;
  private int m_Handle;
  
  public StarObjectClass() {}
  
  private StarObjectClass(StarCoreFactory paramStarCoreFactory, Object[] paramArrayOfObject)
  {
    this.StarCore = paramStarCoreFactory;
    this.StarCore._InitObject(this, paramArrayOfObject);
  }
  
  public StarObjectClass(StarObjectClass paramStarObjectClass)
  {
    this.StarCore = paramStarObjectClass.StarCore;
    this.StarCore._WrapObject(this, paramStarObjectClass);
  }
  
  public void _ARemoteCall(int paramInt1, int paramInt2, String paramString1, String paramString2, int paramInt3, Object... paramVarArgs)
  {
    this.StarCore.StarObject_ARemoteCall(this, paramInt1, paramInt2, paramString1, paramString2, paramInt3, paramVarArgs);
  }
  
  public boolean _Active()
  {
    return this.StarCore.StarObject_Active(this);
  }
  
  public boolean _ActiveClient(int paramInt)
  {
    return this.StarCore.StarObject_ActiveClient(this, paramInt);
  }
  
  public boolean _ActiveCmd(int paramInt)
  {
    return this.StarCore.StarObject_ActiveCmd(this, paramInt);
  }
  
  public StarObjectClass _Assign(StarObjectClass paramStarObjectClass)
  {
    paramStarObjectClass.StarCore = this.StarCore;
    this.StarCore._WrapObject(paramStarObjectClass, this);
    return paramStarObjectClass;
  }
  
  public Object _Call(String paramString, Object... paramVarArgs)
  {
    return this.StarCore.StarObject_Call(this, paramString, paramVarArgs);
  }
  
  public boolean _CanSetStaticData(int paramInt)
  {
    return this.StarCore.StarObject_CanSetStaticData(this, paramInt);
  }
  
  public void _Change(String paramString, Object paramObject)
  {
    this.StarCore.StarObject_Change(this, paramString, paramObject);
  }
  
  public void _ChangeParent(StarObjectClass paramStarObjectClass, String paramString)
  {
    this.StarCore.StarObject_ChangeParent(this, paramStarObjectClass, paramString);
  }
  
  public void _Copy(StarObjectClass paramStarObjectClass)
  {
    this.StarCore.StarObject_Copy(this, paramStarObjectClass);
  }
  
  public boolean _CreateFunc(String paramString1, String paramString2)
  {
    return this.StarCore.StarObject_CreateFunc(this, paramString1, paramString2);
  }
  
  public boolean _CreateFuncEx(String paramString1, String paramString2)
  {
    return this.StarCore.StarObject_CreateFuncEx(this, paramString1, paramString2);
  }
  
  public void _Deactive()
  {
    this.StarCore.StarObject_Deactive(this);
  }
  
  public void _DeactiveClient(int paramInt)
  {
    this.StarCore.StarObject_DeactiveClient(this, paramInt);
  }
  
  public void _DeferFree()
  {
    this.StarCore.StarObject_DeferFree(this);
  }
  
  public void _DeferLoadFromFile(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    this.StarCore.StarObject_DeferLoadFromFile(this, paramString1, paramString2, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
  }
  
  public void _DelFromSDT()
  {
    this.StarCore.StarObject_DelFromSDT(this);
  }
  
  public void _DelFunc(String paramString)
  {
    this.StarCore.StarObject_DelFunc(this, paramString);
  }
  
  public void _E()
  {
    this.StarCore.StarObject_E(this);
  }
  
  public String _EventID(String paramString)
  {
    return this.StarCore.StarObject_EventID(this, paramString);
  }
  
  public void _F(String paramString)
  {
    this.StarCore.StarObject_F(this, paramString);
  }
  
  public boolean _FillSoapRspHeader(StarSXmlClass paramStarSXmlClass)
  {
    return this.StarCore.StarObject_FillSoapRspHeader(this, paramStarSXmlClass);
  }
  
  public Object[] _FirstActiveChild()
  {
    return this.StarCore.StarObject_FirstActiveChild(this);
  }
  
  public StarObjectClass _FirstInst(StarQueryRecordClass paramStarQueryRecordClass)
  {
    return this.StarCore.StarObject_FirstInst(this, paramStarQueryRecordClass);
  }
  
  public void _Free()
  {
    this.StarCore.StarObject_Free(this);
  }
  
  public void _FreeNameValue(String paramString)
  {
    this.StarCore.StarObject_FreeNameValue(this, paramString);
  }
  
  public Object _Get(String paramString)
  {
    return this.StarCore.Common_Get(this, paramString);
  }
  
  public int _GetActiveCmd()
  {
    return this.StarCore.StarObject_GetActiveCmd(this);
  }
  
  public Boolean _GetBool(String paramString)
  {
    return this.StarCore.Common_GetBool(this, paramString);
  }
  
  public StarObjectClass _GetChild(String paramString)
  {
    return this.StarCore.StarObject_GetChild(this, paramString);
  }
  
  public StarObjectClass _GetChildByID(String paramString, int paramInt)
  {
    return this.StarCore.StarObject_GetChildByID(this, paramString, paramInt);
  }
  
  public Double _GetDouble(String paramString)
  {
    return this.StarCore.Common_GetDouble(this, paramString);
  }
  
  public Integer _GetInt(String paramString)
  {
    return this.StarCore.Common_GetInt(this, paramString);
  }
  
  public double _GetNameFloat(String paramString, double paramDouble)
  {
    return this.StarCore.StarObject_GetNameFloat(this, paramString, paramDouble);
  }
  
  public int _GetNameInt(String paramString, int paramInt)
  {
    return this.StarCore.StarObject_GetNameInt(this, paramString, paramInt);
  }
  
  public String _GetNameStr(String paramString1, String paramString2)
  {
    return this.StarCore.StarObject_GetNameStr(this, paramString1, paramString2);
  }
  
  public StarTimeClass _GetNameTime(String paramString, StarTimeClass paramStarTimeClass)
  {
    return this.StarCore.StarObject_GetNameTime(this, paramString, paramStarTimeClass);
  }
  
  public int _GetNameValueType(String paramString)
  {
    return this.StarCore.StarObject_GetNameValueType(this, paramString);
  }
  
  public Object _GetPrivateValue(int paramInt1, int paramInt2)
  {
    return this.StarCore.StarObject_GetPrivateValue(this, paramInt1, paramInt2);
  }
  
  public Object _GetRemoteAttach(String paramString)
  {
    return this.StarCore.StarObject_GetRemoteAttach(this, paramString);
  }
  
  public String _GetStaticData(String paramString1, StarBinBufClass paramStarBinBufClass, String paramString2, boolean paramBoolean)
  {
    return this.StarCore.StarObject_GetStaticData(this, paramString1, paramStarBinBufClass, paramString2, paramBoolean);
  }
  
  public String _GetStr(String paramString)
  {
    return this.StarCore.Common_GetStr(this, paramString);
  }
  
  public StarStructClass _GetStruct(String paramString)
  {
    return (StarStructClass)this.StarCore.Common_Get(this, paramString);
  }
  
  public boolean _Getbool(String paramString)
  {
    return this.StarCore.Common_Getbool(this, paramString);
  }
  
  public double _Getdouble(String paramString)
  {
    return this.StarCore.Common_Getdouble(this, paramString);
  }
  
  public int _Getint(String paramString)
  {
    return this.StarCore.Common_Getint(this, paramString);
  }
  
  public void _Init(String paramString)
  {
    this.StarCore.StarObject_Init(this, paramString);
  }
  
  public void _InsertToSDT()
  {
    this.StarCore.StarObject_InsertToSDT(this);
  }
  
  public boolean _IsActive()
  {
    return this.StarCore.StarObject_IsActive(this);
  }
  
  public boolean _IsChild(StarObjectClass paramStarObjectClass)
  {
    return this.StarCore.StarObject_IsChild(this, paramStarObjectClass);
  }
  
  public boolean _IsDirectInst(StarObjectClass paramStarObjectClass)
  {
    return this.StarCore.StarObject_IsDirectInst(this, paramStarObjectClass);
  }
  
  public boolean _IsInActiveSet()
  {
    return this.StarCore.StarObject_IsInActiveSet(this);
  }
  
  public boolean _IsInFree()
  {
    return this.StarCore.StarObject_IsInFree(this);
  }
  
  public boolean _IsInst(StarObjectClass paramStarObjectClass)
  {
    return this.StarCore.StarObject_IsInst(this, paramStarObjectClass);
  }
  
  public boolean _IsThisClient()
  {
    return this.StarCore.StarObject_IsThisClient(this);
  }
  
  public void _KillTimer(int paramInt)
  {
    this.StarCore.StarObject_KillTimer(this, paramInt);
  }
  
  public boolean _LoadFromBuf(StarBinBufClass paramStarBinBufClass, String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    return this.StarCore.StarObject_LoadFromBuf(this, paramStarBinBufClass, paramString, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
  }
  
  public boolean _LoadFromFile(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    return this.StarCore.StarObject_LoadFromFile(this, paramString1, paramString2, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
  }
  
  public void _LockGC()
  {
    this.StarCore.StarObject_LockGC(this);
  }
  
  public void _MarkChange(String paramString)
  {
    this.StarCore.StarObject_MarkChange(this, paramString);
  }
  
  public void _NV()
  {
    this.StarCore.StarObject_NV(this);
  }
  
  public StarObjectClass _New(Object... paramVarArgs)
  {
    return this.StarCore.StarObject_New(this, paramVarArgs);
  }
  
  public StarObjectClass _NewClient(Object... paramVarArgs)
  {
    return this.StarCore.StarObject_NewClient(this, paramVarArgs);
  }
  
  public StarObjectClass _NewClientEx(Object... paramVarArgs)
  {
    return this.StarCore.StarObject_NewClientEx(this, paramVarArgs);
  }
  
  public StarObjectClass _NewEx(Object... paramVarArgs)
  {
    return this.StarCore.StarObject_NewEx(this, paramVarArgs);
  }
  
  public StarObjectClass _NewGlobal(Object... paramVarArgs)
  {
    return this.StarCore.StarObject_NewGlobal(this, paramVarArgs);
  }
  
  public StarObjectClass _NewGlobalEx(Object... paramVarArgs)
  {
    return this.StarCore.StarObject_NewGlobalEx(this, paramVarArgs);
  }
  
  public Object[] _NextActiveChild(int paramInt)
  {
    return this.StarCore.StarObject_NextActiveChild(this, paramInt);
  }
  
  public StarObjectClass _NextInst(StarQueryRecordClass paramStarQueryRecordClass)
  {
    return this.StarCore.StarObject_NextInst(this, paramStarQueryRecordClass);
  }
  
  public void _PostProcessEvent(String paramString, Object... paramVarArgs)
  {
    this.StarCore.StarObject_PostProcessEvent(this, paramString, paramVarArgs);
  }
  
  public Object[] _ProcessEvent(String paramString, Object... paramVarArgs)
  {
    return this.StarCore.StarObject_ProcessEvent(this, paramString, paramVarArgs);
  }
  
  public void _QueryClose(StarQueryRecordClass paramStarQueryRecordClass)
  {
    this.StarCore.StarObject_QueryClose(this, paramStarQueryRecordClass);
  }
  
  public StarObjectClass _QueryFirstActiveInst(StarQueryRecordClass paramStarQueryRecordClass)
  {
    return this.StarCore.StarObject_QueryFirstActiveInst(this, paramStarQueryRecordClass);
  }
  
  public StarObjectClass _QueryFirstInstFromSDT(StarQueryRecordClass paramStarQueryRecordClass)
  {
    return this.StarCore.StarObject_QueryFirstInstFromSDT(this, paramStarQueryRecordClass);
  }
  
  public StarObjectClass _QueryNextActiveInst(StarQueryRecordClass paramStarQueryRecordClass)
  {
    return this.StarCore.StarObject_QueryNextActiveInst(this, paramStarQueryRecordClass);
  }
  
  public StarObjectClass _QueryNextInstFromSDT(StarQueryRecordClass paramStarQueryRecordClass)
  {
    return this.StarCore.StarObject_QueryNextInstFromSDT(this, paramStarQueryRecordClass);
  }
  
  public int _RegEventFunction(StarObjectClass paramStarObjectClass, String paramString1, String paramString2)
  {
    return this.StarCore.StarObject_RegEventFunction(this, paramStarObjectClass, paramString1, paramString2);
  }
  
  public int _RegFileCallBack(String paramString)
  {
    return this.StarCore.StarObject_RegFileCallBack(this, paramString);
  }
  
  public void _RemoteCall(int paramInt, String paramString, Object... paramVarArgs)
  {
    this.StarCore.StarObject_RemoteCall(this, paramInt, paramString, paramVarArgs);
  }
  
  public void _RemoteCallEx(int paramInt, String paramString, Object... paramVarArgs)
  {
    this.StarCore.StarObject_RemoteCallEx(this, paramInt, paramString, paramVarArgs);
  }
  
  public void _RemoteCallRsp(int paramInt1, int paramInt2, String paramString, int paramInt3, int paramInt4, Object[] paramArrayOfObject, int paramInt5, Object paramObject)
  {
    this.StarCore.StarObject_RemoteCallRsp(this, paramInt1, paramInt2, paramString, paramInt3, paramInt4, paramArrayOfObject, paramInt5, paramObject);
  }
  
  public boolean _RemoteSend(int paramInt, StarParaPkgClass paramStarParaPkgClass)
  {
    return this.StarCore.StarObject_RemoteSend(this, paramInt, paramStarParaPkgClass);
  }
  
  public void _ResetLoad()
  {
    this.StarCore.StarObject_ResetLoad(this);
  }
  
  public void _S(String paramString)
  {
    this.StarCore.StarObject_S(this, paramString);
  }
  
  public void _SLockGC()
  {
    this.StarCore.StarObject_SLockGC(this);
  }
  
  public Object[] _SRemoteCall(int paramInt1, int paramInt2, String paramString, Object... paramVarArgs)
  {
    return this.StarCore.StarObject_SRemoteCall(this, paramInt1, paramInt2, paramString, paramVarArgs);
  }
  
  public boolean _SaveToFile(String paramString1, String paramString2, int paramInt, boolean paramBoolean)
  {
    return this.StarCore.StarObject_SaveToFile(this, paramString1, paramString2, paramInt, paramBoolean);
  }
  
  public boolean _SaveToLuaFunc(String paramString1, String paramString2)
  {
    return this.StarCore.StarObject_SaveToLuaFunc(this, paramString1, paramString2);
  }
  
  public void _Set(String paramString, Object paramObject)
  {
    this.StarCore.Common_Set(this, paramString, paramObject);
  }
  
  public void _SetDeferRspFlag()
  {
    this.StarCore.StarObject_SetDeferRspFlag(this);
  }
  
  public boolean _SetNameFloat(String paramString, double paramDouble, boolean paramBoolean)
  {
    return this.StarCore.StarObject_SetNameFloat(this, paramString, paramDouble, paramBoolean);
  }
  
  public boolean _SetNameInt(String paramString, int paramInt, boolean paramBoolean)
  {
    return this.StarCore.StarObject_SetNameInt(this, paramString, paramInt, paramBoolean);
  }
  
  public boolean _SetNameStr(String paramString1, String paramString2, boolean paramBoolean)
  {
    return this.StarCore.StarObject_SetNameStr(this, paramString1, paramString2, paramBoolean);
  }
  
  public boolean _SetNameTime(String paramString, StarTimeClass paramStarTimeClass, boolean paramBoolean)
  {
    return this.StarCore.StarObject_SetNameTime(this, paramString, paramStarTimeClass, paramBoolean);
  }
  
  public void _SetPrivateValue(int paramInt1, int paramInt2, Object paramObject)
  {
    this.StarCore.StarObject_SetPrivateValue(this, paramInt1, paramInt2, paramObject);
  }
  
  public void _SetRemoteRspAttach(Object... paramVarArgs)
  {
    this.StarCore.StarObject_SetRemoteRspAttach(this, paramVarArgs);
  }
  
  public void _SetRetCode(int paramInt)
  {
    this.StarCore.StarObject_SetRetCode(this, paramInt);
  }
  
  public String _SetStaticData(String paramString, StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.StarObject_SetStaticData(this, paramString, paramStarBinBufClass);
  }
  
  public String _SetStaticDataEx(String paramString1, int paramInt1, int paramInt2, String paramString2)
  {
    return this.StarCore.StarObject_SetStaticDataEx(this, paramString1, paramInt1, paramInt2, paramString2);
  }
  
  public int _SetTimer(int paramInt1, String paramString, int paramInt2, int paramInt3)
  {
    return this.StarCore.StarObject_SetTimer(this, paramInt1, paramString, paramInt2, paramInt3);
  }
  
  public boolean _Tobool(Object paramObject)
  {
    return this.StarCore.Common_Tobool(this, paramObject);
  }
  
  public double _Todouble(Object paramObject)
  {
    return this.StarCore.Common_Todouble(this, paramObject);
  }
  
  public int _Toint(Object paramObject)
  {
    return this.StarCore.Common_Toint(this, paramObject);
  }
  
  public void _UnLockGC()
  {
    this.StarCore.StarObject_UnLockGC(this);
  }
  
  public void _UnRegEventFunction(StarObjectClass paramStarObjectClass, String paramString, int paramInt)
  {
    this.StarCore.StarObject_UnRegEventFunction(this, paramStarObjectClass, paramString, paramInt);
  }
  
  public void _UnRegFileCallBack(int paramInt)
  {
    this.StarCore.StarObject_UnRegFileCallBack(this, paramInt);
  }
  
  public void _V(String paramString)
  {
    this.StarCore.StarObject_V(this, paramString);
  }
  
  public boolean _WaitGetStaticData(String paramString1, String paramString2, boolean paramBoolean)
  {
    return this.StarCore.StarObject_WaitGetStaticData(this, paramString1, paramString2, paramBoolean);
  }
  
  public boolean _WaitMalloc()
  {
    return this.StarCore.StarObject_WaitMalloc(this);
  }
  
  public boolean _WaitSetStaticData(String paramString1, String paramString2, boolean paramBoolean)
  {
    return this.StarCore.StarObject_WaitSetStaticData(this, paramString1, paramString2, paramBoolean);
  }
  
  protected void finalize()
  {
    this.StarCore._TermObject(this);
  }
  
  public String toString()
  {
    return this.StarCore.Common_toString(this);
  }
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srplab/www/starcore/StarObjectClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */