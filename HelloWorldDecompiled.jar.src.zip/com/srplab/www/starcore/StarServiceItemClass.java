package com.srplab.www.starcore;

public class StarServiceItemClass
{
  private StarCoreFactory StarCore;
  private int m_Handle;
  
  public StarServiceItemClass() {}
  
  private StarServiceItemClass(StarCoreFactory paramStarCoreFactory, Object[] paramArrayOfObject)
  {
    this.StarCore = paramStarCoreFactory;
    this.StarCore._InitObject(this, paramArrayOfObject);
  }
  
  public StarServiceItemClass(StarServiceItemClass paramStarServiceItemClass)
  {
    this.StarCore = paramStarServiceItemClass.StarCore;
    this.StarCore._WrapObject(this, paramStarServiceItemClass);
  }
  
  public StarServiceItemClass _Assign(StarServiceItemClass paramStarServiceItemClass)
  {
    paramStarServiceItemClass.StarCore = this.StarCore;
    this.StarCore._WrapObject(paramStarServiceItemClass, this);
    return paramStarServiceItemClass;
  }
  
  public Object _Get(String paramString)
  {
    return this.StarCore.Common_Get(this, paramString);
  }
  
  public Object[] _GetActiveSet()
  {
    return this.StarCore.StarServiceItem_GetActiveSet(this);
  }
  
  public Boolean _GetBool(String paramString)
  {
    return this.StarCore.Common_GetBool(this, paramString);
  }
  
  public Double _GetDouble(String paramString)
  {
    return this.StarCore.Common_GetDouble(this, paramString);
  }
  
  public int _GetGroupSyncStatus(int paramInt)
  {
    return this.StarCore.StarServiceItem_GetGroupSyncStatus(this, paramInt);
  }
  
  public Integer _GetInt(String paramString)
  {
    return this.StarCore.Common_GetInt(this, paramString);
  }
  
  public String _GetStr(String paramString)
  {
    return this.StarCore.Common_GetStr(this, paramString);
  }
  
  public boolean _Getbool(String paramString)
  {
    return this.StarCore.Common_Getbool(this, paramString);
  }
  
  public double _Getdouble(String paramString)
  {
    return this.StarCore.Common_Getdouble(this, paramString);
  }
  
  public int _Getint(String paramString)
  {
    return this.StarCore.Common_Getint(this, paramString);
  }
  
  public boolean _IsSync()
  {
    return this.StarCore.StarServiceItem_IsSync(this);
  }
  
  public StarObjectClass _QueryFirstGroupObject(int paramInt)
  {
    return this.StarCore.StarServiceItem_QueryFirstGroupObject(this, paramInt);
  }
  
  public StarObjectClass _QueryNextGroupObject()
  {
    return this.StarCore.StarServiceItem_QueryNextGroupObject(this);
  }
  
  public void _Set(String paramString, Object paramObject)
  {
    this.StarCore.Common_Set(this, paramString, paramObject);
  }
  
  public void _SetActiveSet(Object... paramVarArgs)
  {
    this.StarCore.StarServiceItem_SetActiveSet(this, paramVarArgs);
  }
  
  public void _SetClientActiveSet(int paramInt, Object... paramVarArgs)
  {
    this.StarCore.StarServiceItem_SetClientActiveSet(this, paramInt, paramVarArgs);
  }
  
  public boolean _Tobool(Object paramObject)
  {
    return this.StarCore.Common_Tobool(this, paramObject);
  }
  
  public double _Todouble(Object paramObject)
  {
    return this.StarCore.Common_Todouble(this, paramObject);
  }
  
  public int _Toint(Object paramObject)
  {
    return this.StarCore.Common_Toint(this, paramObject);
  }
  
  public boolean _WaitSync()
  {
    return this.StarCore.StarServiceItem_WaitSync(this);
  }
  
  protected void finalize()
  {
    this.StarCore._TermObject(this);
  }
  
  public String toString()
  {
    return this.StarCore.Common_toString(this);
  }
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srplab/www/starcore/StarServiceItemClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */