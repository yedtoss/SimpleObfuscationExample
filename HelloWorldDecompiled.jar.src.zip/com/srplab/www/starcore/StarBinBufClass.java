package com.srplab.www.starcore;

public class StarBinBufClass
{
  private StarCoreFactory StarCore;
  private int m_Handle;
  
  public StarBinBufClass(StarCoreFactory paramStarCoreFactory, Object[] paramArrayOfObject)
  {
    this.StarCore = paramStarCoreFactory;
    this.StarCore._InitObject(this, paramArrayOfObject);
  }
  
  public boolean _AnsiToUnicode(String paramString, int paramInt)
  {
    return this.StarCore.StarBinBuf_AnsiToUnicode(this, paramString, paramInt);
  }
  
  public void _Clear()
  {
    this.StarCore.StarBinBuf_Clear(this);
  }
  
  public void _ClearEx(int paramInt1, int paramInt2)
  {
    this.StarCore.StarBinBuf_ClearEx(this, paramInt1, paramInt2);
  }
  
  public void _CloseFile(int paramInt)
  {
    this.StarCore.StarBinBuf_CloseFile(this, paramInt);
  }
  
  public boolean _Expand(int paramInt)
  {
    return this.StarCore.StarBinBuf_Expand(this, paramInt);
  }
  
  public boolean _Fill(int paramInt1, int paramInt2, String paramString)
  {
    return this.StarCore.StarBinBuf_Fill(this, paramInt1, paramInt2, paramString);
  }
  
  public int _FindStr(int paramInt, String paramString)
  {
    return this.StarCore.StarBinBuf_FindStr(this, paramInt, paramString);
  }
  
  public int _FindStri(int paramInt, String paramString)
  {
    return this.StarCore.StarBinBuf_FindStri(this, paramInt, paramString);
  }
  
  public Object _Get(int paramInt1, int paramInt2, String paramString)
  {
    return this.StarCore.StarBinBuf_Get(this, paramInt1, paramInt2, paramString);
  }
  
  public Object _Get(String paramString)
  {
    return this.StarCore.Common_Get(this, paramString);
  }
  
  public Boolean _GetBool(String paramString)
  {
    return this.StarCore.Common_GetBool(this, paramString);
  }
  
  public Double _GetDouble(String paramString)
  {
    return this.StarCore.Common_GetDouble(this, paramString);
  }
  
  public int _GetFileSize(int paramInt)
  {
    return this.StarCore.StarBinBuf_GetFileSize(this, paramInt);
  }
  
  public int _GetHash()
  {
    return this.StarCore.StarBinBuf_GetHash(this);
  }
  
  public Integer _GetInt(String paramString)
  {
    return this.StarCore.Common_GetInt(this, paramString);
  }
  
  public String _GetMD5()
  {
    return this.StarCore.StarBinBuf_GetMD5(this);
  }
  
  public String _GetStr(String paramString)
  {
    return this.StarCore.Common_GetStr(this, paramString);
  }
  
  public boolean _Getbool(String paramString)
  {
    return this.StarCore.Common_Getbool(this, paramString);
  }
  
  public double _Getdouble(String paramString)
  {
    return this.StarCore.Common_Getdouble(this, paramString);
  }
  
  public int _Getint(String paramString)
  {
    return this.StarCore.Common_Getint(this, paramString);
  }
  
  public void _Init(int paramInt)
  {
    this.StarCore.StarBinBuf_Init(this, paramInt);
  }
  
  public void _InsertStr(int paramInt, String paramString)
  {
    this.StarCore.StarBinBuf_InsertStr(this, paramInt, paramString);
  }
  
  public boolean _IsLightBuf()
  {
    return this.StarCore.StarBinBuf_IsLightBuf(this);
  }
  
  public boolean _LoadFromFile(String paramString, boolean paramBoolean)
  {
    return this.StarCore.StarBinBuf_LoadFromFile(this, paramString, paramBoolean);
  }
  
  public int _OpenFile(String paramString1, String paramString2)
  {
    return this.StarCore.StarBinBuf_OpenFile(this, paramString1, paramString2);
  }
  
  public boolean _PackObject(StarObjectClass paramStarObjectClass)
  {
    return this.StarCore.StarBinBuf_PackObject(this, paramStarObjectClass);
  }
  
  public void _Print(String paramString)
  {
    this.StarCore.StarBinBuf_Print(this, paramString);
  }
  
  public int _Read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return this.StarCore.StarBinBuf_Read(this, paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public int _Read2(short[] paramArrayOfShort, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return this.StarCore.StarBinBuf_Read2(this, paramArrayOfShort, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public int _Read4(int[] paramArrayOfInt, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    return this.StarCore.StarBinBuf_Read4(this, paramArrayOfInt, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
  }
  
  public int _ReadFile(int paramInt1, int paramInt2, int paramInt3)
  {
    return this.StarCore.StarBinBuf_ReadFile(this, paramInt1, paramInt2, paramInt3);
  }
  
  public boolean _SaveToFile(String paramString, boolean paramBoolean)
  {
    return this.StarCore.StarBinBuf_SaveToFile(this, paramString, paramBoolean);
  }
  
  public int _Set(int paramInt1, int paramInt2, String paramString, Object paramObject)
  {
    return this.StarCore.StarBinBuf_Set(this, paramInt1, paramInt2, paramString, paramObject);
  }
  
  public void _Set(String paramString, Object paramObject)
  {
    this.StarCore.Common_Set(this, paramString, paramObject);
  }
  
  public boolean _SetOffset(int paramInt)
  {
    return this.StarCore.StarBinBuf_SetOffset(this, paramInt);
  }
  
  public boolean _ToAnsi()
  {
    return this.StarCore.StarBinBuf_ToAnsi(this);
  }
  
  public boolean _ToUTF8()
  {
    return this.StarCore.StarBinBuf_ToUTF8(this);
  }
  
  public boolean _Tobool(Object paramObject)
  {
    return this.StarCore.Common_Tobool(this, paramObject);
  }
  
  public double _Todouble(Object paramObject)
  {
    return this.StarCore.Common_Todouble(this, paramObject);
  }
  
  public int _Toint(Object paramObject)
  {
    return this.StarCore.Common_Toint(this, paramObject);
  }
  
  public boolean _UnPackObject(StarObjectClass paramStarObjectClass)
  {
    return this.StarCore.StarBinBuf_UnPackObject(this, paramStarObjectClass);
  }
  
  public boolean _UnicodeToAnsi(String paramString, int paramInt)
  {
    return this.StarCore.StarBinBuf_UnicodeToAnsi(this, paramString, paramInt);
  }
  
  public int _Write(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    return this.StarCore.StarBinBuf_Write(this, paramInt1, paramArrayOfByte, paramInt2);
  }
  
  public int _Write2(int paramInt1, short[] paramArrayOfShort, int paramInt2, int paramInt3, int paramInt4)
  {
    return this.StarCore.StarBinBuf_Write2(this, paramInt1, paramArrayOfShort, paramInt2, paramInt3, paramInt4);
  }
  
  public int _Write4(int paramInt1, int[] paramArrayOfInt, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    return this.StarCore.StarBinBuf_Write4(this, paramInt1, paramArrayOfInt, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
  }
  
  public int _WriteFile(int paramInt1, int paramInt2, int paramInt3)
  {
    return this.StarCore.StarBinBuf_WriteFile(this, paramInt1, paramInt2, paramInt3);
  }
  
  public int _WriteFromMemoryFile(StarServiceClass paramStarServiceClass, int paramInt, String paramString)
  {
    return this.StarCore.StarBinBuf_WriteFromMemoryFile(this, paramStarServiceClass, paramInt, paramString);
  }
  
  protected void finalize()
  {
    this.StarCore._TermObject(this);
  }
  
  public String toString()
  {
    return this.StarCore.Common_toString(this);
  }
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srplab/www/starcore/StarBinBufClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */