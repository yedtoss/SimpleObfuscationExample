package com.srplab.www.starcore;

public class StarFontClass
{
  byte CharSet;
  int Height;
  String Name;
  int Size;
  byte Style;
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srplab/www/starcore/StarFontClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */