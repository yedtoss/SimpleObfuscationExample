package com.srplab.www.starcore;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class StarCoreFactoryPath
{
  public static String StarCoreOperationPath = null;
  public static String StarCoreShareLibraryPath = null;
  
  public static void CreatePath(Runtime paramRuntime, String paramString)
  {
    paramRuntime = new File(paramString);
    if (!paramRuntime.exists()) {
      paramRuntime.mkdirs();
    }
    try
    {
      if (Runtime.getRuntime().exec("chmod 777 " + paramRuntime).waitFor() != 0) {
        paramRuntime.delete();
      }
      return;
    }
    catch (Exception paramString)
    {
      paramRuntime.delete();
    }
  }
  
  public static void InitDefault(Runtime paramRuntime, String paramString)
  {
    SetPath(paramString + "/lib", paramString + "/files");
    CreatePath(paramRuntime, paramString + "/files/srplab");
    CreatePath(paramRuntime, paramString + "/files/sdcard");
  }
  
  public static void Install(InputStream paramInputStream, String paramString, Boolean paramBoolean)
  {
    unzip(paramInputStream, paramString, paramBoolean);
  }
  
  public static void InstallDefault(InputStream paramInputStream, Boolean paramBoolean)
  {
    unzip(paramInputStream, StarCoreOperationPath, paramBoolean);
  }
  
  public static void SetPath(String paramString1, String paramString2)
  {
    StarCoreShareLibraryPath = paramString1;
    StarCoreOperationPath = paramString2;
  }
  
  private static void unzip(InputStream paramInputStream, String paramString, Boolean paramBoolean)
  {
    ZipInputStream localZipInputStream;
    do
    {
      for (;;)
      {
        try
        {
          localZipInputStream = new ZipInputStream(paramInputStream);
          paramInputStream = localZipInputStream.getNextEntry();
          arrayOfByte = new byte['Ѐ'];
          if (paramInputStream == null) {
            break label214;
          }
          new File(paramString).mkdir();
          if (!paramInputStream.isDirectory()) {
            continue;
          }
          paramInputStream = paramInputStream.getName();
          paramInputStream = paramInputStream.substring(0, paramInputStream.length() - 1);
          new File(paramString + File.separator + paramInputStream).mkdir();
        }
        catch (FileNotFoundException paramInputStream)
        {
          byte[] arrayOfByte;
          paramInputStream.printStackTrace();
          return;
          paramInputStream.close();
          continue;
        }
        catch (IOException paramInputStream)
        {
          paramInputStream.printStackTrace();
          return;
        }
        paramInputStream = localZipInputStream.getNextEntry();
      }
      paramInputStream = new File(paramString + File.separator + paramInputStream.getName());
    } while ((paramInputStream.exists()) && (paramBoolean.booleanValue() != true));
    paramInputStream.createNewFile();
    paramInputStream = new FileOutputStream(paramInputStream);
    for (;;)
    {
      int i = localZipInputStream.read(arrayOfByte);
      if (i == -1) {
        break;
      }
      paramInputStream.write(arrayOfByte, 0, i);
    }
    label214:
    localZipInputStream.close();
  }
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srplab/www/starcore/StarCoreFactoryPath.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */