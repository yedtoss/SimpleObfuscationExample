package com.srplab.www.starcore;

public class StarTimeClass
{
  short wDay;
  short wDayOfWeek;
  short wHour;
  short wMilliseconds;
  short wMinute;
  short wMonth;
  short wSecond;
  short wYear;
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srplab/www/starcore/StarTimeClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */