package com.srplab.www.starcore;

public class StarServiceClass
{
  private StarCoreFactory StarCore;
  private int m_Handle;
  
  public StarServiceClass() {}
  
  private StarServiceClass(StarCoreFactory paramStarCoreFactory, Object[] paramArrayOfObject)
  {
    this.StarCore = paramStarCoreFactory;
    this.StarCore._InitObject(this, paramArrayOfObject);
  }
  
  public StarServiceClass(StarServiceClass paramStarServiceClass)
  {
    this.StarCore = paramStarServiceClass.StarCore;
    this.StarCore._WrapObject(this, paramStarServiceClass);
  }
  
  public boolean _AcceptClient(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2, int paramInt2, int paramInt3, int paramInt4)
  {
    return this.StarCore.StarService_AcceptClient(this, paramInt1, paramBoolean1, paramBoolean2, paramString1, paramString2, paramInt2, paramInt3, paramInt4);
  }
  
  public void _ActiveAllSysRootItem()
  {
    this.StarCore.StarService_ActiveAllSysRootItem(this);
  }
  
  public void _ActiveCSysRootItem(int paramInt, String paramString)
  {
    this.StarCore.StarService_ActiveCSysRootItem(this, paramInt, paramString);
  }
  
  public void _ActiveSysRootItem(String paramString)
  {
    this.StarCore.StarService_ActiveSysRootItem(this, paramString);
  }
  
  public boolean _ApplyLog()
  {
    return this.StarCore.StarService_ApplyLog(this);
  }
  
  public StarServiceClass _Assign(StarServiceClass paramStarServiceClass)
  {
    paramStarServiceClass.StarCore = this.StarCore;
    this.StarCore._WrapObject(paramStarServiceClass, this);
    return paramStarServiceClass;
  }
  
  public boolean _AtomicAttach(int paramInt, String paramString)
  {
    return this.StarCore.StarService_AtomicAttach(this, paramInt, paramString);
  }
  
  public StarObjectClass _AtomicToObject(int paramInt)
  {
    return this.StarCore.StarService_AtomicToObject(this, paramInt);
  }
  
  public void _CheckPassword(boolean paramBoolean)
  {
    this.StarCore.StarService_CheckPassword(this, paramBoolean);
  }
  
  public void _ClearLog()
  {
    this.StarCore.StarService_ClearLog(this);
  }
  
  public void _ClearStatic(int paramInt)
  {
    this.StarCore.StarService_ClearStatic(this, paramInt);
  }
  
  public int _CreateAtomicAttachAttribute(int paramInt1, String paramString1, String paramString2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, String paramString3, String paramString4)
  {
    return this.StarCore.StarService_CreateAtomicAttachAttribute(this, paramInt1, paramString1, paramString2, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9, paramString3, paramString4);
  }
  
  public int _CreateAtomicAttribute(int paramInt1, String paramString1, String paramString2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, String paramString3, String paramString4)
  {
    return this.StarCore.StarService_CreateAtomicAttribute(this, paramInt1, paramString1, paramString2, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9, paramString3, paramString4);
  }
  
  public int _CreateAtomicDepend(String paramString)
  {
    return this.StarCore.StarService_CreateAtomicDepend(this, paramString);
  }
  
  public int _CreateAtomicEditModule(String paramString1, String paramString2)
  {
    return this.StarCore.StarService_CreateAtomicEditModule(this, paramString1, paramString2);
  }
  
  public int _CreateAtomicFuncParaAttribute(int paramInt1, String paramString1, String paramString2, int paramInt2, String paramString3)
  {
    return this.StarCore.StarService_CreateAtomicFuncParaAttribute(this, paramInt1, paramString1, paramString2, paramInt2, paramString3);
  }
  
  public int _CreateAtomicFuncRetAttribute(int paramInt1, int paramInt2, String paramString)
  {
    return this.StarCore.StarService_CreateAtomicFuncRetAttribute(this, paramInt1, paramInt2, paramString);
  }
  
  public int _CreateAtomicFunction(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    return this.StarCore.StarService_CreateAtomicFunction(this, paramInt, paramString1, paramString2, paramString3, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
  }
  
  public Object[] _CreateAtomicFunctionEx(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2, String paramString4, boolean paramBoolean3, boolean paramBoolean4)
  {
    return this.StarCore.StarService_CreateAtomicFunctionEx(this, paramInt, paramString1, paramString2, paramString3, paramBoolean1, paramBoolean2, paramString4, paramBoolean3, paramBoolean4);
  }
  
  public Object[] _CreateAtomicFunctionSimple(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2)
  {
    return this.StarCore.StarService_CreateAtomicFunctionSimple(this, paramInt, paramString1, paramString2, paramString3, paramBoolean1, paramBoolean2);
  }
  
  public int _CreateAtomicInEvent(int paramInt, String paramString1, String paramString2, String paramString3)
  {
    return this.StarCore.StarService_CreateAtomicInEvent(this, paramInt, paramString1, paramString2, paramString3);
  }
  
  public int _CreateAtomicLuaFunction(int paramInt, String paramString1, String paramString2, String paramString3)
  {
    return this.StarCore.StarService_CreateAtomicLuaFunction(this, paramInt, paramString1, paramString2, paramString3);
  }
  
  public int _CreateAtomicMacro(String paramString, int paramInt)
  {
    return this.StarCore.StarService_CreateAtomicMacro(this, paramString, paramInt);
  }
  
  public int _CreateAtomicMacroItem(int paramInt, String paramString1, String paramString2)
  {
    return this.StarCore.StarService_CreateAtomicMacroItem(this, paramInt, paramString1, paramString2);
  }
  
  public int _CreateAtomicModule(String paramString1, int paramInt, String paramString2)
  {
    return this.StarCore.StarService_CreateAtomicModule(this, paramString1, paramInt, paramString2);
  }
  
  public int _CreateAtomicObject(int paramInt1, String paramString1, int paramInt2, String paramString2, String paramString3)
  {
    return this.StarCore.StarService_CreateAtomicObject(this, paramInt1, paramString1, paramInt2, paramString2, paramString3);
  }
  
  public Object[] _CreateAtomicObjectAttributeSimple(int paramInt, String paramString)
  {
    return this.StarCore.StarService_CreateAtomicObjectAttributeSimple(this, paramInt, paramString);
  }
  
  public Object[] _CreateAtomicObjectSimple(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    return this.StarCore.StarService_CreateAtomicObjectSimple(this, paramString1, paramString2, paramString3, paramString4);
  }
  
  public int _CreateAtomicOutEvent(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean)
  {
    return this.StarCore.StarService_CreateAtomicOutEvent(this, paramInt, paramString1, paramString2, paramString3, paramBoolean);
  }
  
  public int _CreateAtomicOvlFunction(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean)
  {
    return this.StarCore.StarService_CreateAtomicOvlFunction(this, paramInt, paramString1, paramString2, paramString3, paramString4, paramBoolean);
  }
  
  public int _CreateAtomicScript(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    return this.StarCore.StarService_CreateAtomicScript(this, paramInt, paramString1, paramString2, paramString3, paramString4);
  }
  
  public int _CreateAtomicStruct(String paramString1, String paramString2, String paramString3)
  {
    return this.StarCore.StarService_CreateAtomicStruct(this, paramString1, paramString2, paramString3);
  }
  
  public int _CreateAtomicStructAttribute(int paramInt1, String paramString1, String paramString2, int paramInt2, String paramString3)
  {
    return this.StarCore.StarService_CreateAtomicStructAttribute(this, paramInt1, paramString1, paramString2, paramInt2, paramString3);
  }
  
  public Object[] _CreateAtomicStructSimple(String paramString1, String paramString2, String paramString3)
  {
    return this.StarCore.StarService_CreateAtomicStructSimple(this, paramString1, paramString2, paramString3);
  }
  
  public int _CreateAtomicSysRootItem(String paramString1, String paramString2)
  {
    return this.StarCore.StarService_CreateAtomicSysRootItem(this, paramString1, paramString2);
  }
  
  public boolean _CreateSysRootItem(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    return this.StarCore.StarService_CreateSysRootItem(this, paramString1, paramString2, paramString3, paramString4);
  }
  
  public StarServiceItemClass _CreateSysRootItemEx(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    return this.StarCore.StarService_CreateSysRootItemEx(this, paramString1, paramString2, paramString3, paramString4);
  }
  
  public boolean _CreateUser(String paramString1, String paramString2, int paramInt)
  {
    return this.StarCore.StarService_CreateUser(this, paramString1, paramString2, paramInt);
  }
  
  public void _DeactiveAll()
  {
    this.StarCore.StarService_DeactiveAll(this);
  }
  
  public void _DeactiveCSysRootItem(int paramInt, String paramString)
  {
    this.StarCore.StarService_DeactiveCSysRootItem(this, paramInt, paramString);
  }
  
  public void _DeactiveSysRootItem(String paramString)
  {
    this.StarCore.StarService_DeactiveSysRootItem(this, paramString);
  }
  
  public void _DelClient(int paramInt)
  {
    this.StarCore.StarService_DelClient(this, paramInt);
  }
  
  public void _DeleteUser(String paramString)
  {
    this.StarCore.StarService_DeleteUser(this, paramString);
  }
  
  public Object[] _DoFile(String paramString1, String paramString2, String paramString3)
  {
    return this.StarCore.StarService_DoFile(this, paramString1, paramString2, paramString3);
  }
  
  public void _DownLoad(String paramString1, String paramString2, String paramString3)
  {
    this.StarCore.StarService_DownLoad(this, paramString1, paramString2, paramString3);
  }
  
  public void _Exit()
  {
    this.StarCore.StarService_Exit(this);
  }
  
  public Object[] _ExportModule(String paramString)
  {
    return this.StarCore.StarService_ExportModule(this, paramString);
  }
  
  public Object[] _FirstUser(StarQueryRecordClass paramStarQueryRecordClass)
  {
    return this.StarCore.StarService_FirstUser(this, paramStarQueryRecordClass);
  }
  
  public void _ForceToSaveStatic()
  {
    this.StarCore.StarService_ForceToSaveStatic(this);
  }
  
  public Object _Get(String paramString)
  {
    return this.StarCore.Common_Get(this, paramString);
  }
  
  public String _GetAtomicID(int paramInt)
  {
    return this.StarCore.StarService_GetAtomicID(this, paramInt);
  }
  
  public int _GetAtomicObjectEx(int paramInt, String paramString)
  {
    return this.StarCore.StarService_GetAtomicObjectEx(this, paramInt, paramString);
  }
  
  public int _GetAtomicSysRootItem(String paramString)
  {
    return this.StarCore.StarService_GetAtomicSysRootItem(this, paramString);
  }
  
  public Boolean _GetBool(String paramString)
  {
    return this.StarCore.Common_GetBool(this, paramString);
  }
  
  public Object[] _GetClientInfo(int paramInt)
  {
    return this.StarCore.StarService_GetClientInfo(this, paramInt);
  }
  
  public int _GetClientNumber()
  {
    return this.StarCore.StarService_GetClientNumber(this);
  }
  
  public StarObjectClass _GetClientObject()
  {
    return this.StarCore.StarService_GetClientObject(this);
  }
  
  public Double _GetDouble(String paramString)
  {
    return this.StarCore.Common_GetDouble(this, paramString);
  }
  
  public Integer _GetInt(String paramString)
  {
    return this.StarCore.Common_GetInt(this, paramString);
  }
  
  public String _GetLogFile()
  {
    return this.StarCore.StarService_GetLogFile(this);
  }
  
  public int _GetOPPermission()
  {
    return this.StarCore.StarService_GetOPPermission(this);
  }
  
  public StarObjectClass _GetObject(String paramString)
  {
    return this.StarCore.StarService_GetObject(this, paramString);
  }
  
  public StarObjectClass _GetObjectEx(String paramString)
  {
    return this.StarCore.StarService_GetObjectEx(this, paramString);
  }
  
  public StarObjectClass _GetObjectEx2(String paramString1, String paramString2)
  {
    return this.StarCore.StarService_GetObjectEx2(this, paramString1, paramString2);
  }
  
  public StarObjectClass _GetObjectFromLua(String paramString)
  {
    return this.StarCore.StarService_GetObjectFromLua(this, paramString);
  }
  
  public String _GetPeerIP(int paramInt)
  {
    return this.StarCore.StarService_GetPeerIP(this, paramInt);
  }
  
  public int _GetServerID()
  {
    return this.StarCore.StarService_GetServerID(this);
  }
  
  public String _GetStr(String paramString)
  {
    return this.StarCore.Common_GetStr(this, paramString);
  }
  
  public StarServiceItemClass _GetSysRootItem(String paramString)
  {
    return this.StarCore.StarService_GetSysRootItem(this, paramString);
  }
  
  public boolean _Getbool(String paramString)
  {
    return this.StarCore.Common_Getbool(this, paramString);
  }
  
  public double _Getdouble(String paramString)
  {
    return this.StarCore.Common_Getdouble(this, paramString);
  }
  
  public int _Getint(String paramString)
  {
    return this.StarCore.Common_Getint(this, paramString);
  }
  
  public void _HttpDownLoad(String paramString1, String paramString2, String paramString3)
  {
    this.StarCore.StarService_HttpDownLoad(this, paramString1, paramString2, paramString3);
  }
  
  public void _HttpDownLoadAbort()
  {
    this.StarCore.StarService_HttpDownLoadAbort(this);
  }
  
  public boolean _IsActive()
  {
    return this.StarCore.StarService_IsActive(this);
  }
  
  public boolean _IsChange()
  {
    return this.StarCore.StarService_IsChange(this);
  }
  
  public boolean _IsOsSupport(int paramInt1, int paramInt2)
  {
    return this.StarCore.StarService_IsOsSupport(this, paramInt1, paramInt2);
  }
  
  public boolean _IsServiceRegistered()
  {
    return this.StarCore.StarService_IsServiceRegistered(this);
  }
  
  public StarObjectClass _New(Object... paramVarArgs)
  {
    return this.StarCore.StarService_New(this, paramVarArgs);
  }
  
  public StarObjectClass _NewClient(Object... paramVarArgs)
  {
    return this.StarCore.StarService_NewClient(this, paramVarArgs);
  }
  
  public StarObjectClass _NewClientEx(Object... paramVarArgs)
  {
    return this.StarCore.StarService_NewClientEx(this, paramVarArgs);
  }
  
  public StarObjectClass _NewEx(Object... paramVarArgs)
  {
    return this.StarCore.StarService_NewEx(this, paramVarArgs);
  }
  
  public StarObjectClass _NewGlobal(Object... paramVarArgs)
  {
    return this.StarCore.StarService_NewGlobal(this, paramVarArgs);
  }
  
  public StarObjectClass _NewGlobalEx(Object... paramVarArgs)
  {
    return this.StarCore.StarService_NewGlobalEx(this, paramVarArgs);
  }
  
  public Object[] _NextUser(StarQueryRecordClass paramStarQueryRecordClass)
  {
    return this.StarCore.StarService_NextUser(this, paramStarQueryRecordClass);
  }
  
  public int _ObjectToAtomic(StarObjectClass paramStarObjectClass)
  {
    return this.StarCore.StarService_ObjectToAtomic(this, paramStarObjectClass);
  }
  
  public boolean _ObjectToXml(StarSXmlClass paramStarSXmlClass, Object paramObject, String paramString1, boolean paramBoolean1, boolean paramBoolean2, String paramString2)
  {
    return this.StarCore.StarService_ObjectToXml(this, paramStarSXmlClass, paramObject, paramString1, paramBoolean1, paramBoolean2, paramString2);
  }
  
  public void _PackStaticData()
  {
    this.StarCore.StarService_PackStaticData(this);
  }
  
  public void _PrintClientInfo()
  {
    this.StarCore.StarService_PrintClientInfo(this);
  }
  
  public void _PrintInfo()
  {
    this.StarCore.StarService_PrintInfo(this);
  }
  
  public void _PrintMacro(String paramString)
  {
    this.StarCore.StarService_PrintMacro(this, paramString);
  }
  
  public Object[] _QueryFirstDepend()
  {
    return this.StarCore.StarService_QueryFirstDepend(this);
  }
  
  public StarObjectClass _QueryFirstFromSDT()
  {
    return this.StarCore.StarService_QueryFirstFromSDT(this);
  }
  
  public String _QueryFirstSysRootItem()
  {
    return this.StarCore.StarService_QueryFirstSysRootItem(this);
  }
  
  public Object[] _QueryNextDepend()
  {
    return this.StarCore.StarService_QueryNextDepend(this);
  }
  
  public StarObjectClass _QueryNextFromSDT()
  {
    return this.StarCore.StarService_QueryNextFromSDT(this);
  }
  
  public String _QueryNextSysRootItem()
  {
    return this.StarCore.StarService_QueryNextSysRootItem(this);
  }
  
  public void _Redirect(int paramInt1, String paramString1, String paramString2, int paramInt2, StarParaPkgClass paramStarParaPkgClass, String paramString3)
  {
    this.StarCore.StarService_Redirect(this, paramInt1, paramString1, paramString2, paramInt2, paramStarParaPkgClass, paramString3);
  }
  
  public void _RegClientOpFunction(String paramString)
  {
    this.StarCore.StarService_RegClientOpFunction(this, paramString);
  }
  
  public int _RegFileCallBack(String paramString)
  {
    return this.StarCore.StarService_RegFileCallBack(this, paramString);
  }
  
  public void _RegMachineFunction(String paramString)
  {
    this.StarCore.StarService_RegMachineFunction(this, paramString);
  }
  
  public void _RegServerWebDownFunction(String paramString)
  {
    this.StarCore.StarService_RegServerWebDownFunction(this, paramString);
  }
  
  public Object[] _RunScript(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    return this.StarCore.StarService_RunScript(this, paramString1, paramString2, paramString3, paramString4);
  }
  
  public Object[] _RunScriptEx(String paramString1, StarBinBufClass paramStarBinBufClass, String paramString2, String paramString3)
  {
    return this.StarCore.StarService_RunScriptEx(this, paramString1, paramStarBinBufClass, paramString2, paramString3);
  }
  
  public void _Save(String paramString)
  {
    this.StarCore.StarService_Save(this, paramString);
  }
  
  public boolean _ServiceToXml(StarSXmlClass paramStarSXmlClass, String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, String paramString3)
  {
    return this.StarCore.StarService_ServiceToXml(this, paramStarSXmlClass, paramString1, paramString2, paramBoolean1, paramBoolean2, paramString3);
  }
  
  public void _Set(String paramString, Object paramObject)
  {
    this.StarCore.Common_Set(this, paramString, paramObject);
  }
  
  public boolean _SetAtomicAttributeCombobox(int paramInt, String paramString)
  {
    return this.StarCore.StarService_SetAtomicAttributeCombobox(this, paramInt, paramString);
  }
  
  public boolean _SetAtomicAttributeLength(int paramInt1, int paramInt2)
  {
    return this.StarCore.StarService_SetAtomicAttributeLength(this, paramInt1, paramInt2);
  }
  
  public boolean _SetAtomicAttributeStruct(int paramInt1, int paramInt2)
  {
    return this.StarCore.StarService_SetAtomicAttributeStruct(this, paramInt1, paramInt2);
  }
  
  public boolean _SetAtomicAttributeSyncFlag(int paramInt1, int paramInt2)
  {
    return this.StarCore.StarService_SetAtomicAttributeSyncFlag(this, paramInt1, paramInt2);
  }
  
  public boolean _SetAtomicObjectAttribute(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4)
  {
    return this.StarCore.StarService_SetAtomicObjectAttribute(this, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4);
  }
  
  public boolean _SetAtomicObjectSyncGroup(int paramInt1, int paramInt2)
  {
    return this.StarCore.StarService_SetAtomicObjectSyncGroup(this, paramInt1, paramInt2);
  }
  
  public boolean _SetClientObject(int paramInt, StarObjectClass paramStarObjectClass)
  {
    return this.StarCore.StarService_SetClientObject(this, paramInt, paramStarObjectClass);
  }
  
  public void _SetLog(Object paramObject, boolean paramBoolean)
  {
    this.StarCore.StarService_SetLog(this, paramObject, paramBoolean);
  }
  
  public void _SetLogFile(String paramString)
  {
    this.StarCore.StarService_SetLogFile(this, paramString);
  }
  
  public void _SetPrivateTag(int paramInt)
  {
    this.StarCore.StarService_SetPrivateTag(this, paramInt);
  }
  
  public boolean _SysRootItemToXml(StarSXmlClass paramStarSXmlClass, String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, String paramString3)
  {
    return this.StarCore.StarService_SysRootItemToXml(this, paramStarSXmlClass, paramString1, paramString2, paramBoolean1, paramBoolean2, paramString3);
  }
  
  public boolean _Tobool(Object paramObject)
  {
    return this.StarCore.Common_Tobool(this, paramObject);
  }
  
  public double _Todouble(Object paramObject)
  {
    return this.StarCore.Common_Todouble(this, paramObject);
  }
  
  public int _Toint(Object paramObject)
  {
    return this.StarCore.Common_Toint(this, paramObject);
  }
  
  public void _UnRegFileCallBack(int paramInt)
  {
    this.StarCore.StarService_UnRegFileCallBack(this, paramInt);
  }
  
  public void _UpLoad(String paramString1, String paramString2, String paramString3)
  {
    this.StarCore.StarService_UpLoad(this, paramString1, paramString2, paramString3);
  }
  
  public boolean _XmlToObject(StarSXmlClass paramStarSXmlClass, Object paramObject, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    return this.StarCore.StarService_XmlToObject(this, paramStarSXmlClass, paramObject, paramString1, paramString2, paramString3, paramString4);
  }
  
  public boolean _XmlToSysRootItem(StarSXmlClass paramStarSXmlClass, String paramString1, String paramString2, String paramString3)
  {
    return this.StarCore.StarService_XmlToSysRootItem(this, paramStarSXmlClass, paramString1, paramString2, paramString3);
  }
  
  protected void finalize()
  {
    this.StarCore._TermObject(this);
  }
  
  public String toString()
  {
    return this.StarCore.Common_toString(this);
  }
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srplab/www/starcore/StarServiceClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */