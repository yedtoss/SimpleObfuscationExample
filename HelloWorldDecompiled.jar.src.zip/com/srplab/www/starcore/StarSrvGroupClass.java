package com.srplab.www.starcore;

public class StarSrvGroupClass
{
  private StarCoreFactory StarCore;
  private int m_Handle;
  
  public StarSrvGroupClass() {}
  
  private StarSrvGroupClass(StarCoreFactory paramStarCoreFactory, Object[] paramArrayOfObject)
  {
    this.StarCore = paramStarCoreFactory;
    this.StarCore._InitObject(this, paramArrayOfObject);
  }
  
  public StarSrvGroupClass(StarSrvGroupClass paramStarSrvGroupClass)
  {
    this.StarCore = paramStarSrvGroupClass.StarCore;
    this.StarCore._WrapObject(this, paramStarSrvGroupClass);
  }
  
  public void _AllocCooperator(String paramString)
  {
    this.StarCore.SrvGroup_AllocCooperator(this, paramString);
  }
  
  public void _AppEvent(int paramInt, String paramString)
  {
    this.StarCore.SrvGroup_AppEvent(this, paramInt, paramString);
  }
  
  public StarSrvGroupClass _Assign(StarSrvGroupClass paramStarSrvGroupClass)
  {
    paramStarSrvGroupClass.StarCore = this.StarCore;
    this.StarCore._WrapObject(paramStarSrvGroupClass, this);
    return paramStarSrvGroupClass;
  }
  
  public void _ClearClientWnd()
  {
    this.StarCore.SrvGroup_ClearClientWnd(this);
  }
  
  public void _ClearLuaGlobal()
  {
    this.StarCore.SrvGroup_ClearLuaGlobal(this);
  }
  
  public void _ClearSearchPath()
  {
    this.StarCore.SrvGroup_ClearSearchPath(this);
  }
  
  public void _ClearService()
  {
    this.StarCore.SrvGroup_ClearService(this);
  }
  
  public void _ClearServiceEx()
  {
    this.StarCore.SrvGroup_ClearServiceEx(this);
  }
  
  public void _CloseLuaEdit()
  {
    this.StarCore.SrvGroup_CloseLuaEdit(this);
  }
  
  public void _CloseSocketConnect(int paramInt)
  {
    this.StarCore.SrvGroup_CloseSocketConnect(this, paramInt);
  }
  
  public int _Connect(String paramString1, String paramString2, int paramInt1, int paramInt2, String paramString3, String paramString4, StarParaPkgClass paramStarParaPkgClass, String paramString5)
  {
    return this.StarCore.SrvGroup_Connect(this, paramString1, paramString2, paramInt1, paramInt2, paramString3, paramString4, paramStarParaPkgClass, paramString5);
  }
  
  public StarServiceClass _Connect2(String paramString1, String paramString2, int paramInt, String paramString3, String paramString4, String paramString5, StarParaPkgClass paramStarParaPkgClass)
  {
    return this.StarCore.SrvGroup_Connect2(this, paramString1, paramString2, paramInt, paramString3, paramString4, paramString5, paramStarParaPkgClass);
  }
  
  public StarServiceClass _Connect2Ex(String paramString1, String paramString2, String paramString3, String paramString4, StarParaPkgClass paramStarParaPkgClass)
  {
    return this.StarCore.SrvGroup_Connect2Ex(this, paramString1, paramString2, paramString3, paramString4, paramStarParaPkgClass);
  }
  
  public int _ConnectEx(String paramString1, int paramInt, String paramString2, String paramString3, StarParaPkgClass paramStarParaPkgClass, String paramString4)
  {
    return this.StarCore.SrvGroup_ConnectEx(this, paramString1, paramInt, paramString2, paramString3, paramStarParaPkgClass, paramString4);
  }
  
  public StarServiceClass _CreateService(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, String paramString4)
  {
    return this.StarCore.SrvGroup_CreateService(this, paramString1, paramString2, paramString3, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramString4);
  }
  
  public StarServiceClass _CreateServiceEx(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, String paramString4)
  {
    return this.StarCore.SrvGroup_CreateServiceEx(this, paramString1, paramString2, paramString3, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramString4);
  }
  
  public void _DisConnect()
  {
    this.StarCore.SrvGroup_DisConnect(this);
  }
  
  public boolean _DoFile(String paramString1, String paramString2)
  {
    return this.StarCore.SrvGroup_DoFile(this, paramString1, paramString2);
  }
  
  public void _ExitVSSystem(String paramString)
  {
    this.StarCore.SrvGroup_ExitVSSystem(this, paramString);
  }
  
  public boolean _ExportServiceHeader(String paramString1, String paramString2)
  {
    return this.StarCore.SrvGroup_ExportServiceHeader(this, paramString1, paramString2);
  }
  
  public Object[] _FirstDoc(StarQueryRecordClass paramStarQueryRecordClass)
  {
    return this.StarCore.SrvGroup_FirstDoc(this, paramStarQueryRecordClass);
  }
  
  public String _FirstSearchPath(StarQueryRecordClass paramStarQueryRecordClass)
  {
    return this.StarCore.SrvGroup_FirstSearchPath(this, paramStarQueryRecordClass);
  }
  
  public void _FreeCooperator(String paramString)
  {
    this.StarCore.SrvGroup_FreeCooperator(this, paramString);
  }
  
  public String _FromClipBoard()
  {
    return this.StarCore.SrvGroup_FromClipBoard(this);
  }
  
  public Object _Get(String paramString)
  {
    return this.StarCore.Common_Get(this, paramString);
  }
  
  public Boolean _GetBool(String paramString)
  {
    return this.StarCore.Common_GetBool(this, paramString);
  }
  
  public Object[] _GetClientSize()
  {
    return this.StarCore.SrvGroup_GetClientSize(this);
  }
  
  public void _GetConfig(StarSXmlClass paramStarSXmlClass)
  {
    this.StarCore.SrvGroup_GetConfig(this, paramStarSXmlClass);
  }
  
  public String _GetConfigEnvTag()
  {
    return this.StarCore.SrvGroup_GetConfigEnvTag(this);
  }
  
  public String _GetConfigHost()
  {
    return this.StarCore.SrvGroup_GetConfigHost(this);
  }
  
  public Object[] _GetConfigResult()
  {
    return this.StarCore.SrvGroup_GetConfigResult(this);
  }
  
  public String _GetCurrentPath()
  {
    return this.StarCore.SrvGroup_GetCurrentPath(this);
  }
  
  public Double _GetDouble(String paramString)
  {
    return this.StarCore.Common_GetDouble(this, paramString);
  }
  
  public Integer _GetInt(String paramString)
  {
    return this.StarCore.Common_GetInt(this, paramString);
  }
  
  public String _GetModulePath()
  {
    return this.StarCore.SrvGroup_GetModulePath(this);
  }
  
  public String _GetSRPConfigPath()
  {
    return this.StarCore.SrvGroup_GetSRPConfigPath(this);
  }
  
  public String _GetSRPTempPath()
  {
    return this.StarCore.SrvGroup_GetSRPTempPath(this);
  }
  
  public Object[] _GetServerUrlInfo()
  {
    return this.StarCore.SrvGroup_GetServerUrlInfo(this);
  }
  
  public StarServiceClass _GetService(String paramString1, String paramString2)
  {
    return this.StarCore.SrvGroup_GetService(this, paramString1, paramString2);
  }
  
  public StarServiceClass _GetServiceEx(String paramString1, String paramString2, String paramString3)
  {
    return this.StarCore.SrvGroup_GetServiceEx(this, paramString1, paramString2, paramString3);
  }
  
  public String _GetServicePath()
  {
    return this.StarCore.SrvGroup_GetServicePath(this);
  }
  
  public String _GetStaticVersion(Object paramObject)
  {
    return this.StarCore.SrvGroup_GetStaticVersion(this, paramObject);
  }
  
  public String _GetStr(String paramString)
  {
    return this.StarCore.Common_GetStr(this, paramString);
  }
  
  public Object[] _GetVersion()
  {
    return this.StarCore.SrvGroup_GetVersion(this);
  }
  
  public String _GetVersionInfo()
  {
    return this.StarCore.SrvGroup_GetVersionInfo(this);
  }
  
  public boolean _GetWSDL(int paramInt, String paramString, StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.SrvGroup_GetWSDL(this, paramInt, paramString, paramStarBinBufClass);
  }
  
  public Object[] _GetWindowPos()
  {
    return this.StarCore.SrvGroup_GetWindowPos(this);
  }
  
  public boolean _Getbool(String paramString)
  {
    return this.StarCore.Common_Getbool(this, paramString);
  }
  
  public double _Getdouble(String paramString)
  {
    return this.StarCore.Common_Getdouble(this, paramString);
  }
  
  public int _Getint(String paramString)
  {
    return this.StarCore.Common_Getint(this, paramString);
  }
  
  public int _Hash(String paramString)
  {
    return this.StarCore.SrvGroup_Hash(this, paramString);
  }
  
  public void _HideClientWnd()
  {
    this.StarCore.SrvGroup_HideClientWnd(this);
  }
  
  public void _HideWindow()
  {
    this.StarCore.SrvGroup_HideWindow(this);
  }
  
  public void _HttpDownLoad(String paramString1, String paramString2, String paramString3)
  {
    this.StarCore.SrvGroup_HttpDownLoad(this, paramString1, paramString2, paramString3);
  }
  
  public void _HttpDownLoadAbort()
  {
    this.StarCore.SrvGroup_HttpDownLoadAbort(this);
  }
  
  public void _HyperLink(String paramString, boolean paramBoolean)
  {
    this.StarCore.SrvGroup_HyperLink(this, paramString, paramBoolean);
  }
  
  public int _ID()
  {
    return this.StarCore.SrvGroup_ID(this);
  }
  
  public String _ImportDynaService(String paramString)
  {
    return this.StarCore.SrvGroup_ImportDynaService(this, paramString);
  }
  
  public boolean _ImportService(String paramString, boolean paramBoolean)
  {
    return this.StarCore.SrvGroup_ImportService(this, paramString, paramBoolean);
  }
  
  public boolean _ImportServiceEx(String paramString, boolean paramBoolean)
  {
    return this.StarCore.SrvGroup_ImportServiceEx(this, paramString, paramBoolean);
  }
  
  public boolean _ImportServiceFromXmlBuf(String paramString, boolean paramBoolean)
  {
    return this.StarCore.SrvGroup_ImportServiceFromXmlBuf(this, paramString, paramBoolean);
  }
  
  public boolean _ImportServiceWithPath(String paramString1, String paramString2, boolean paramBoolean)
  {
    return this.StarCore.SrvGroup_ImportServiceWithPath(this, paramString1, paramString2, paramBoolean);
  }
  
  public void _InsertSearchPath(String paramString)
  {
    this.StarCore.SrvGroup_InsertSearchPath(this, paramString);
  }
  
  public boolean _IsAppActive()
  {
    return this.StarCore.SrvGroup_IsAppActive(this);
  }
  
  public boolean _IsBinBuf(Object paramObject)
  {
    return this.StarCore.SrvGroup_IsBinBuf(this, paramObject);
  }
  
  public boolean _IsClient()
  {
    return this.StarCore.SrvGroup_IsClient(this);
  }
  
  public boolean _IsCommInterface(Object paramObject)
  {
    return this.StarCore.SrvGroup_IsCommInterface(this, paramObject);
  }
  
  public boolean _IsConnect()
  {
    return this.StarCore.SrvGroup_IsConnect(this);
  }
  
  public boolean _IsDebug()
  {
    return this.StarCore.SrvGroup_IsDebug(this);
  }
  
  public boolean _IsDefaultServer()
  {
    return this.StarCore.SrvGroup_IsDefaultServer(this);
  }
  
  public boolean _IsFunctionPara(Object paramObject)
  {
    return this.StarCore.SrvGroup_IsFunctionPara(this, paramObject);
  }
  
  public boolean _IsInSync()
  {
    return this.StarCore.SrvGroup_IsInSync(this);
  }
  
  public boolean _IsObject(Object paramObject)
  {
    return this.StarCore.SrvGroup_IsObject(this, paramObject);
  }
  
  public boolean _IsParaPkg(Object paramObject)
  {
    return this.StarCore.SrvGroup_IsParaPkg(this, paramObject);
  }
  
  public boolean _IsQueryRecord(Object paramObject)
  {
    return this.StarCore.SrvGroup_IsQueryRecord(this, paramObject);
  }
  
  public boolean _IsSXml(Object paramObject)
  {
    return this.StarCore.SrvGroup_IsSXml(this, paramObject);
  }
  
  public boolean _IsServer()
  {
    return this.StarCore.SrvGroup_IsServer(this);
  }
  
  public boolean _IsServerClient()
  {
    return this.StarCore.SrvGroup_IsServerClient(this);
  }
  
  public boolean _IsServiceSync()
  {
    return this.StarCore.SrvGroup_IsServiceSync(this);
  }
  
  public boolean _IsWindowVisible()
  {
    return this.StarCore.SrvGroup_IsWindowVisible(this);
  }
  
  public void _KillTimer(int paramInt)
  {
    this.StarCore.SrvGroup_KillTimer(this, paramInt);
  }
  
  public StarServiceClass _LoadService(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
  {
    return this.StarCore.SrvGroup_LoadService(this, paramString1, paramString2, paramString3, paramBoolean);
  }
  
  public StarServiceClass _LoadServiceEx(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
  {
    return this.StarCore.SrvGroup_LoadServiceEx(this, paramString1, paramString2, paramString3, paramBoolean);
  }
  
  public StarServiceClass _LoadServiceWithPath(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean)
  {
    return this.StarCore.SrvGroup_LoadServiceWithPath(this, paramString1, paramString2, paramString3, paramString4, paramBoolean);
  }
  
  public boolean _LockLuaTable()
  {
    return this.StarCore.SrvGroup_LockLuaTable(this);
  }
  
  public void _LuaEditDisp(String paramString)
  {
    this.StarCore.SrvGroup_LuaEditDisp(this, paramString);
  }
  
  public void _LuaEditHelp(int paramInt, String paramString)
  {
    this.StarCore.SrvGroup_LuaEditHelp(this, paramInt, paramString);
  }
  
  public String _MD5(String paramString)
  {
    return this.StarCore.SrvGroup_MD5(this, paramString);
  }
  
  public Object[] _MemorySize()
  {
    return this.StarCore.SrvGroup_MemorySize(this);
  }
  
  public void _MessageBox(String paramString1, String paramString2)
  {
    this.StarCore.SrvGroup_MessageBox(this, paramString1, paramString2);
  }
  
  public void _MoveWindow(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    this.StarCore.SrvGroup_MoveWindow(this, paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean);
  }
  
  public StarBinBufClass _NewBinBuf()
  {
    return this.StarCore.SrvGroup_NewBinBuf(this);
  }
  
  public StarCommInterfaceClass _NewCommInterface()
  {
    return this.StarCore.SrvGroup_NewCommInterface(this);
  }
  
  public StarFunctionParaClass _NewFunctionPara()
  {
    return this.StarCore.SrvGroup_NewFunctionPara(this);
  }
  
  public StarParaPkgClass _NewParaPkg()
  {
    return this.StarCore.SrvGroup_NewParaPkg(this);
  }
  
  public StarQueryRecordClass _NewQueryRecord()
  {
    return this.StarCore.SrvGroup_NewQueryRecord(this);
  }
  
  public StarSXmlClass _NewSXml()
  {
    return this.StarCore.SrvGroup_NewSXml(this);
  }
  
  public Object[] _NextDoc(StarQueryRecordClass paramStarQueryRecordClass)
  {
    return this.StarCore.SrvGroup_NextDoc(this, paramStarQueryRecordClass);
  }
  
  public String _NextSearchPath(StarQueryRecordClass paramStarQueryRecordClass)
  {
    return this.StarCore.SrvGroup_NextSearchPath(this, paramStarQueryRecordClass);
  }
  
  public boolean _OpenLuaEdit(String paramString, int paramInt, boolean paramBoolean)
  {
    return this.StarCore.SrvGroup_OpenLuaEdit(this, paramString, paramInt, paramBoolean);
  }
  
  public void _Print(String paramString)
  {
    this.StarCore.SrvGroup_Print(this, paramString);
  }
  
  public void _PrintError(int paramInt, String paramString)
  {
    this.StarCore.SrvGroup_PrintError(this, paramInt, paramString);
  }
  
  public void _ProgramRestart()
  {
    this.StarCore.SrvGroup_ProgramRestart(this);
  }
  
  public Object[] _QuyeryStatistic(int paramInt)
  {
    return this.StarCore.SrvGroup_QuyeryStatistic(this, paramInt);
  }
  
  public void _RegDispatchCallBack(String paramString)
  {
    this.StarCore.SrvGroup_RegDispatchCallBack(this, paramString);
  }
  
  public int _RegFileReqCallBack(String paramString)
  {
    return this.StarCore.SrvGroup_RegFileReqCallBack(this, paramString);
  }
  
  public void _RegWebDownFunction(String paramString)
  {
    this.StarCore.SrvGroup_RegWebDownFunction(this, paramString);
  }
  
  public void _RegisterDoc(Object paramObject, String paramString)
  {
    this.StarCore.SrvGroup_RegisterDoc(this, paramObject, paramString);
  }
  
  public boolean _RegisterServer(String paramString)
  {
    return this.StarCore.SrvGroup_RegisterServer(this, paramString);
  }
  
  public int _RunFromUrl(String paramString, int paramInt, boolean paramBoolean)
  {
    return this.StarCore.SrvGroup_RunFromUrl(this, paramString, paramInt, paramBoolean);
  }
  
  public boolean _RunScript(String paramString1, String paramString2, String paramString3)
  {
    return this.StarCore.SrvGroup_RunScript(this, paramString1, paramString2, paramString3);
  }
  
  public boolean _RunScriptEx(String paramString1, StarBinBufClass paramStarBinBufClass, String paramString2)
  {
    return this.StarCore.SrvGroup_RunScriptEx(this, paramString1, paramStarBinBufClass, paramString2);
  }
  
  public int _SConnect(String paramString1, String paramString2, int paramInt, String paramString3, String paramString4, StarParaPkgClass paramStarParaPkgClass)
  {
    return this.StarCore.SrvGroup_SConnect(this, paramString1, paramString2, paramInt, paramString3, paramString4, paramStarParaPkgClass);
  }
  
  public int _SConnectEx(String paramString1, String paramString2, String paramString3, StarParaPkgClass paramStarParaPkgClass)
  {
    return this.StarCore.SrvGroup_SConnectEx(this, paramString1, paramString2, paramString3, paramStarParaPkgClass);
  }
  
  public boolean _ServicePathIsSet()
  {
    return this.StarCore.SrvGroup_ServicePathIsSet(this);
  }
  
  public void _Set(String paramString, Object paramObject)
  {
    this.StarCore.Common_Set(this, paramString, paramObject);
  }
  
  public void _SetBkColor(int paramInt)
  {
    this.StarCore.SrvGroup_SetBkColor(this, paramInt);
  }
  
  public void _SetCaption(String paramString)
  {
    this.StarCore.SrvGroup_SetCaption(this, paramString);
  }
  
  public void _SetClientBkColor(int paramInt)
  {
    this.StarCore.SrvGroup_SetClientBkColor(this, paramInt);
  }
  
  public boolean _SetClientPort(String paramString, int paramInt)
  {
    return this.StarCore.SrvGroup_SetClientPort(this, paramString, paramInt);
  }
  
  public void _SetClientSize(int paramInt1, int paramInt2)
  {
    this.StarCore.SrvGroup_SetClientSize(this, paramInt1, paramInt2);
  }
  
  public void _SetColor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    this.StarCore.SrvGroup_SetColor(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
  }
  
  public void _SetCurrentPath(String paramString)
  {
    this.StarCore.SrvGroup_SetCurrentPath(this, paramString);
  }
  
  public boolean _SetDataServerAddr(boolean paramBoolean, String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2)
  {
    return this.StarCore.SrvGroup_SetDataServerAddr(this, paramBoolean, paramString1, paramString2, paramInt1, paramString3, paramInt2);
  }
  
  public boolean _SetDebugPort(String paramString, int paramInt)
  {
    return this.StarCore.SrvGroup_SetDebugPort(this, paramString, paramInt);
  }
  
  public void _SetEnvCurrentUrl(String paramString)
  {
    this.StarCore.SrvGroup_SetEnvCurrentUrl(this, paramString);
  }
  
  public void _SetEnvPara(StarParaPkgClass paramStarParaPkgClass)
  {
    this.StarCore.SrvGroup_SetEnvPara(this, paramStarParaPkgClass);
  }
  
  public void _SetIdleActive(boolean paramBoolean)
  {
    this.StarCore.SrvGroup_SetIdleActive(this, paramBoolean);
  }
  
  public boolean _SetOutputPort(String paramString, int paramInt)
  {
    return this.StarCore.SrvGroup_SetOutputPort(this, paramString, paramInt);
  }
  
  public void _SetServerPara(int paramInt1, int paramInt2, int paramInt3)
  {
    this.StarCore.SrvGroup_SetServerPara(this, paramInt1, paramInt2, paramInt3);
  }
  
  public void _SetServicePath(String paramString)
  {
    this.StarCore.SrvGroup_SetServicePath(this, paramString);
  }
  
  public boolean _SetTelnetPort(int paramInt)
  {
    return this.StarCore.SrvGroup_SetTelnetPort(this, paramInt);
  }
  
  public int _SetTimer(int paramInt1, String paramString, int paramInt2, int paramInt3)
  {
    return this.StarCore.SrvGroup_SetTimer(this, paramInt1, paramString, paramInt2, paramInt3);
  }
  
  public boolean _SetWebServerPort(String paramString, int paramInt1, int paramInt2, int paramInt3)
  {
    return this.StarCore.SrvGroup_SetWebServerPort(this, paramString, paramInt1, paramInt2, paramInt3);
  }
  
  public void _SetWindowStatus(int paramInt)
  {
    this.StarCore.SrvGroup_SetWindowStatus(this, paramInt);
  }
  
  public void _SetWindowStyle(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5)
  {
    this.StarCore.SrvGroup_SetWindowStyle(this, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5);
  }
  
  public int _SetupSocketClient(String paramString1, String paramString2, int paramInt, String paramString3)
  {
    return this.StarCore.SrvGroup_SetupSocketClient(this, paramString1, paramString2, paramInt, paramString3);
  }
  
  public int _SetupSocketServer(String paramString1, int paramInt, String paramString2)
  {
    return this.StarCore.SrvGroup_SetupSocketServer(this, paramString1, paramInt, paramString2);
  }
  
  public void _ShowClientWnd()
  {
    this.StarCore.SrvGroup_ShowClientWnd(this);
  }
  
  public void _ShowStatusMenu(boolean paramBoolean1, boolean paramBoolean2)
  {
    this.StarCore.SrvGroup_ShowStatusMenu(this, paramBoolean1, paramBoolean2);
  }
  
  public void _ShowWindow()
  {
    this.StarCore.SrvGroup_ShowWindow(this);
  }
  
  public boolean _SocketSend(int paramInt, StarParaPkgClass paramStarParaPkgClass, boolean paramBoolean)
  {
    return this.StarCore.SrvGroup_SocketSend(this, paramInt, paramStarParaPkgClass, paramBoolean);
  }
  
  public void _StartVSService(String paramString)
  {
    this.StarCore.SrvGroup_StartVSService(this, paramString);
  }
  
  public int _TickCount()
  {
    return this.StarCore.SrvGroup_TickCount(this);
  }
  
  public void _ToClipBoard(String paramString)
  {
    this.StarCore.SrvGroup_ToClipBoard(this, paramString);
  }
  
  public boolean _Tobool(Object paramObject)
  {
    return this.StarCore.Common_Tobool(this, paramObject);
  }
  
  public double _Todouble(Object paramObject)
  {
    return this.StarCore.Common_Todouble(this, paramObject);
  }
  
  public int _Toint(Object paramObject)
  {
    return this.StarCore.Common_Toint(this, paramObject);
  }
  
  public boolean _UnLockLuaTable()
  {
    return this.StarCore.SrvGroup_UnLockLuaTable(this);
  }
  
  public void _UnRegFileReqCallBack(int paramInt)
  {
    this.StarCore.SrvGroup_UnRegFileReqCallBack(this, paramInt);
  }
  
  public void _UnRegisterDoc(Object paramObject)
  {
    this.StarCore.SrvGroup_UnRegisterDoc(this, paramObject);
  }
  
  public boolean _WaitServiceSync(int paramInt)
  {
    return this.StarCore.SrvGroup_WaitServiceSync(this, paramInt);
  }
  
  public void _WebServiceRefresh()
  {
    this.StarCore.SrvGroup_WebServiceRefresh(this);
  }
  
  public boolean _XmlToService(StarSXmlClass paramStarSXmlClass, String paramString1, String paramString2, String paramString3)
  {
    return this.StarCore.SrvGroup_XmlToService(this, paramStarSXmlClass, paramString1, paramString2, paramString3);
  }
  
  public boolean _XmlToServiceEx(String paramString1, String paramString2)
  {
    return this.StarCore.SrvGroup_XmlToServiceEx(this, paramString1, paramString2);
  }
  
  protected void finalize()
  {
    this.StarCore._TermObject(this);
  }
  
  public String toString()
  {
    return this.StarCore.Common_toString(this);
  }
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srplab/www/starcore/StarSrvGroupClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */