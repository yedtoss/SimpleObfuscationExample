package com.srplab.www.starcore;

import java.util.Hashtable;

public class StarParaPkgClass
{
  private StarCoreFactory StarCore;
  private int m_Handle;
  
  private StarParaPkgClass(StarCoreFactory paramStarCoreFactory, Object[] paramArrayOfObject)
  {
    this.StarCore = paramStarCoreFactory;
    this.StarCore._InitObject(this, paramArrayOfObject);
  }
  
  public boolean _AppendFrom(StarParaPkgClass paramStarParaPkgClass)
  {
    return this.StarCore.StarParaPkg_AppendFrom(this, paramStarParaPkgClass);
  }
  
  public void _Clear()
  {
    this.StarCore.StarParaPkg_Clear(this);
  }
  
  public void _ClearChangeFlag(int paramInt)
  {
    this.StarCore.StarParaPkg_ClearChangeFlag(this, paramInt);
  }
  
  public void _ClearChangeFlagEx()
  {
    this.StarCore.StarParaPkg_ClearChangeFlagEx(this);
  }
  
  public boolean _CopyBin(int paramInt1, StarParaPkgClass paramStarParaPkgClass, int paramInt2)
  {
    return this.StarCore.StarParaPkg_CopyBin(this, paramInt1, paramStarParaPkgClass, paramInt2);
  }
  
  public void _Del(int paramInt)
  {
    this.StarCore.StarParaPkg_Del(this, paramInt);
  }
  
  public boolean _Exchange(int paramInt1, int paramInt2)
  {
    return this.StarCore.StarParaPkg_Exchange(this, paramInt1, paramInt2);
  }
  
  public boolean _FromDict(Hashtable paramHashtable)
  {
    return this.StarCore.StarParaPkg_FromDict(this, paramHashtable);
  }
  
  public boolean _FromTuple(Object[] paramArrayOfObject)
  {
    return this.StarCore.StarParaPkg_FromTuple(this, paramArrayOfObject);
  }
  
  public Object _Get(int paramInt)
  {
    return this.StarCore.StarParaPkg_Get(this, paramInt);
  }
  
  public Object _Get(String paramString)
  {
    return this.StarCore.Common_Get(this, paramString);
  }
  
  public Boolean _GetBool(String paramString)
  {
    return this.StarCore.Common_GetBool(this, paramString);
  }
  
  public Double _GetDouble(String paramString)
  {
    return this.StarCore.Common_GetDouble(this, paramString);
  }
  
  public int _GetHash(int paramInt)
  {
    return this.StarCore.StarParaPkg_GetHash(this, paramInt);
  }
  
  public Integer _GetInt(String paramString)
  {
    return this.StarCore.Common_GetInt(this, paramString);
  }
  
  public String _GetStr(String paramString)
  {
    return this.StarCore.Common_GetStr(this, paramString);
  }
  
  public StarTimeClass _GetTime(int paramInt)
  {
    return this.StarCore.StarParaPkg_GetTime(this, paramInt);
  }
  
  public String _GetUUID(int paramInt)
  {
    return this.StarCore.StarParaPkg_GetUUID(this, paramInt);
  }
  
  public boolean _Getbool(String paramString)
  {
    return this.StarCore.Common_Getbool(this, paramString);
  }
  
  public double _Getdouble(String paramString)
  {
    return this.StarCore.Common_Getdouble(this, paramString);
  }
  
  public int _Getint(String paramString)
  {
    return this.StarCore.Common_Getint(this, paramString);
  }
  
  public boolean _InsertEmpty(int paramInt)
  {
    return this.StarCore.StarParaPkg_InsertEmpty(this, paramInt);
  }
  
  public boolean _IsChangeFlag(int paramInt)
  {
    return this.StarCore.StarParaPkg_IsChangeFlag(this, paramInt);
  }
  
  public boolean _IsChangeFlagEx()
  {
    return this.StarCore.StarParaPkg_IsChangeFlagEx(this);
  }
  
  public boolean _LoadChangeFromBuf(StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.StarParaPkg_LoadChangeFromBuf(this, paramStarBinBufClass);
  }
  
  public boolean _LoadFromFile(int paramInt, String paramString)
  {
    return this.StarCore.StarParaPkg_LoadFromFile(this, paramInt, paramString);
  }
  
  public boolean _SaveChangeToBuf(StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.StarParaPkg_SaveChangeToBuf(this, paramStarBinBufClass);
  }
  
  public boolean _SaveChangeToBufEx(StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.StarParaPkg_SaveChangeToBufEx(this, paramStarBinBufClass);
  }
  
  public boolean _SaveToFile(int paramInt, String paramString)
  {
    return this.StarCore.StarParaPkg_SaveToFile(this, paramInt, paramString);
  }
  
  public void _Set(String paramString, Object paramObject)
  {
    this.StarCore.Common_Set(this, paramString, paramObject);
  }
  
  public boolean _Set(int paramInt, Object paramObject)
  {
    return this.StarCore.StarParaPkg_Set(this, paramInt, paramObject);
  }
  
  public void _SetChangeFlag(int paramInt)
  {
    this.StarCore.StarParaPkg_SetChangeFlag(this, paramInt);
  }
  
  public void _SetChangeFlagEx()
  {
    this.StarCore.StarParaPkg_SetChangeFlagEx(this);
  }
  
  public boolean _SetTime(int paramInt, StarTimeClass paramStarTimeClass)
  {
    return this.StarCore.StarParaPkg_SetTime(this, paramInt, paramStarTimeClass);
  }
  
  public int _T(int paramInt)
  {
    return this.StarCore.StarParaPkg_T(this, paramInt);
  }
  
  public Hashtable _ToDict()
  {
    return this.StarCore.StarParaPkg_ToDict(this);
  }
  
  public Object[] _ToTuple()
  {
    return this.StarCore.StarParaPkg_ToTuple(this);
  }
  
  public boolean _Tobool(Object paramObject)
  {
    return this.StarCore.Common_Tobool(this, paramObject);
  }
  
  public double _Todouble(Object paramObject)
  {
    return this.StarCore.Common_Todouble(this, paramObject);
  }
  
  public int _Toint(Object paramObject)
  {
    return this.StarCore.Common_Toint(this, paramObject);
  }
  
  protected void finalize()
  {
    this.StarCore._TermObject(this);
  }
  
  public String toString()
  {
    return this.StarCore.Common_toString(this);
  }
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srplab/www/starcore/StarParaPkgClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */