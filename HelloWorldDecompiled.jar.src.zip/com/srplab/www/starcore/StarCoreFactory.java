package com.srplab.www.starcore;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Hashtable;

public class StarCoreFactory
{
  private static StarCoreFactory m_Factory = null;
  private int m_Handle;
  
  static
  {
    if (StarCoreFactoryPath.StarCoreShareLibraryPath == null)
    {
      System.load("/data/data/com.srplab.starcore/lib/libstar_java.so");
      return;
    }
    System.load(StarCoreFactoryPath.StarCoreShareLibraryPath + "/libstar_java.so");
  }
  
  private StarCoreFactory()
  {
    if (StarCoreFactoryPath.StarCoreShareLibraryPath == null)
    {
      _InitObject(this, null);
      return;
    }
    _InitObject(this, new String[] { StarCoreFactoryPath.StarCoreShareLibraryPath, StarCoreFactoryPath.StarCoreOperationPath });
  }
  
  public static StarCoreFactory GetFactory()
  {
    if (m_Factory != null) {
      return m_Factory;
    }
    m_Factory = new StarCoreFactory();
    return m_Factory;
  }
  
  public static int GetStarClassType(Class paramClass)
  {
    if (paramClass.equals(Boolean.TYPE)) {
      return 1;
    }
    if (paramClass.equals(Integer.TYPE)) {
      return 2;
    }
    if (paramClass.equals(Double.TYPE)) {
      return 4;
    }
    if (paramClass.equals(String.class)) {
      return 5;
    }
    if (paramClass.equals(Boolean.class)) {
      return 6;
    }
    if (paramClass.equals(Integer.class)) {
      return 7;
    }
    if (paramClass.equals(Double.class)) {
      return 9;
    }
    if (paramClass.equals(StarBinBufClass.class)) {
      return 10;
    }
    if (paramClass.equals(StarCommInterfaceClass.class)) {
      return 11;
    }
    if (paramClass.equals(StarCoreFactory.class)) {
      return 12;
    }
    if (paramClass.equals(StarFontClass.class)) {
      return 13;
    }
    if (paramClass.equals(StarFunctionParaClass.class)) {
      return 14;
    }
    if (paramClass.equals(StarObjectClass.class)) {
      return 15;
    }
    if (paramClass.equals(StarParaPkgClass.class)) {
      return 16;
    }
    if (paramClass.equals(StarQueryRecordClass.class)) {
      return 17;
    }
    if (paramClass.equals(StarRectClass.class)) {
      return 18;
    }
    if (paramClass.equals(StarServiceClass.class)) {
      return 19;
    }
    if (paramClass.equals(StarServiceItemClass.class)) {
      return 20;
    }
    if (paramClass.equals(StarSrvGroupClass.class)) {
      return 21;
    }
    if (paramClass.equals(StarStructClass.class)) {
      return 22;
    }
    if (paramClass.equals(StarSXmlClass.class)) {
      return 23;
    }
    if (paramClass.equals(StarTimeClass.class)) {
      return 24;
    }
    if (paramClass.equals(Object[].class)) {
      return 25;
    }
    if (paramClass.equals(Hashtable.class)) {
      return 26;
    }
    if (paramClass.equals(Object.class)) {
      return 27;
    }
    if (paramClass.equals(Void.TYPE)) {
      return 28;
    }
    return 0;
  }
  
  public static boolean IsFieldDefinedInStarObjectExtends(Field paramField)
  {
    paramField = paramField.getDeclaringClass();
    return (!paramField.equals(Object.class)) && (!paramField.equals(StarObjectClass.class));
  }
  
  public static boolean IsMethodDefinedInStarObjectExtends(Method paramMethod)
  {
    paramMethod = paramMethod.getDeclaringClass();
    return (!paramMethod.equals(Object.class)) && (!paramMethod.equals(StarObjectClass.class));
  }
  
  public static void StarCoreGC() {}
  
  public native Object Common_Get(Object paramObject, String paramString);
  
  public native Boolean Common_GetBool(Object paramObject, String paramString);
  
  public native Double Common_GetDouble(Object paramObject, String paramString);
  
  public native Integer Common_GetInt(Object paramObject, String paramString);
  
  public native String Common_GetStr(Object paramObject, String paramString);
  
  public native boolean Common_Getbool(Object paramObject, String paramString);
  
  public native double Common_Getdouble(Object paramObject, String paramString);
  
  public native int Common_Getint(Object paramObject, String paramString);
  
  public native void Common_Set(Object paramObject1, String paramString, Object paramObject2);
  
  public native boolean Common_Tobool(Object paramObject1, Object paramObject2);
  
  public native double Common_Todouble(Object paramObject1, Object paramObject2);
  
  public native int Common_Toint(Object paramObject1, Object paramObject2);
  
  public native String Common_toString(Object paramObject);
  
  public native void SrvGroup_AllocCooperator(Object paramObject, String paramString);
  
  public native void SrvGroup_AppEvent(Object paramObject, int paramInt, String paramString);
  
  public native void SrvGroup_ClearClientWnd(Object paramObject);
  
  public native void SrvGroup_ClearLuaGlobal(Object paramObject);
  
  public native void SrvGroup_ClearSearchPath(Object paramObject);
  
  public native void SrvGroup_ClearService(Object paramObject);
  
  public native void SrvGroup_ClearServiceEx(Object paramObject);
  
  public native void SrvGroup_CloseLuaEdit(Object paramObject);
  
  public native void SrvGroup_CloseSocketConnect(Object paramObject, int paramInt);
  
  public native int SrvGroup_Connect(Object paramObject, String paramString1, String paramString2, int paramInt1, int paramInt2, String paramString3, String paramString4, StarParaPkgClass paramStarParaPkgClass, String paramString5);
  
  public native StarServiceClass SrvGroup_Connect2(Object paramObject, String paramString1, String paramString2, int paramInt, String paramString3, String paramString4, String paramString5, StarParaPkgClass paramStarParaPkgClass);
  
  public native StarServiceClass SrvGroup_Connect2Ex(Object paramObject, String paramString1, String paramString2, String paramString3, String paramString4, StarParaPkgClass paramStarParaPkgClass);
  
  public native int SrvGroup_ConnectEx(Object paramObject, String paramString1, int paramInt, String paramString2, String paramString3, StarParaPkgClass paramStarParaPkgClass, String paramString4);
  
  public native StarServiceClass SrvGroup_CreateService(Object paramObject, String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, String paramString4);
  
  public native StarServiceClass SrvGroup_CreateServiceEx(Object paramObject, String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, String paramString4);
  
  public native void SrvGroup_DisConnect(Object paramObject);
  
  public native boolean SrvGroup_DoFile(Object paramObject, String paramString1, String paramString2);
  
  public native void SrvGroup_ExitVSSystem(Object paramObject, String paramString);
  
  public native boolean SrvGroup_ExportServiceHeader(Object paramObject, String paramString1, String paramString2);
  
  public native Object[] SrvGroup_FirstDoc(Object paramObject, StarQueryRecordClass paramStarQueryRecordClass);
  
  public native String SrvGroup_FirstSearchPath(Object paramObject, StarQueryRecordClass paramStarQueryRecordClass);
  
  public native void SrvGroup_FreeCooperator(Object paramObject, String paramString);
  
  public native String SrvGroup_FromClipBoard(Object paramObject);
  
  public native Object[] SrvGroup_GetClientSize(Object paramObject);
  
  public native void SrvGroup_GetConfig(Object paramObject, StarSXmlClass paramStarSXmlClass);
  
  public native String SrvGroup_GetConfigEnvTag(Object paramObject);
  
  public native String SrvGroup_GetConfigHost(Object paramObject);
  
  public native Object[] SrvGroup_GetConfigResult(Object paramObject);
  
  public native String SrvGroup_GetCurrentPath(Object paramObject);
  
  public native String SrvGroup_GetModulePath(Object paramObject);
  
  public native String SrvGroup_GetSRPConfigPath(Object paramObject);
  
  public native String SrvGroup_GetSRPTempPath(Object paramObject);
  
  public native Object[] SrvGroup_GetServerUrlInfo(Object paramObject);
  
  public native StarServiceClass SrvGroup_GetService(Object paramObject, String paramString1, String paramString2);
  
  public native StarServiceClass SrvGroup_GetServiceEx(Object paramObject, String paramString1, String paramString2, String paramString3);
  
  public native String SrvGroup_GetServicePath(Object paramObject);
  
  public native String SrvGroup_GetStaticVersion(Object paramObject1, Object paramObject2);
  
  public native Object[] SrvGroup_GetVersion(Object paramObject);
  
  public native String SrvGroup_GetVersionInfo(Object paramObject);
  
  public native boolean SrvGroup_GetWSDL(Object paramObject, int paramInt, String paramString, StarBinBufClass paramStarBinBufClass);
  
  public native Object[] SrvGroup_GetWindowPos(Object paramObject);
  
  public native int SrvGroup_Hash(Object paramObject, String paramString);
  
  public native void SrvGroup_HideClientWnd(Object paramObject);
  
  public native void SrvGroup_HideWindow(Object paramObject);
  
  public native void SrvGroup_HttpDownLoad(Object paramObject, String paramString1, String paramString2, String paramString3);
  
  public native void SrvGroup_HttpDownLoadAbort(Object paramObject);
  
  public native void SrvGroup_HyperLink(Object paramObject, String paramString, boolean paramBoolean);
  
  public native int SrvGroup_ID(Object paramObject);
  
  public native String SrvGroup_ImportDynaService(Object paramObject, String paramString);
  
  public native boolean SrvGroup_ImportService(Object paramObject, String paramString, boolean paramBoolean);
  
  public native boolean SrvGroup_ImportServiceEx(Object paramObject, String paramString, boolean paramBoolean);
  
  public native boolean SrvGroup_ImportServiceFromXmlBuf(Object paramObject, String paramString, boolean paramBoolean);
  
  public native boolean SrvGroup_ImportServiceWithPath(Object paramObject, String paramString1, String paramString2, boolean paramBoolean);
  
  public native void SrvGroup_InsertSearchPath(Object paramObject, String paramString);
  
  public native boolean SrvGroup_IsAppActive(Object paramObject);
  
  public native boolean SrvGroup_IsBinBuf(Object paramObject1, Object paramObject2);
  
  public native boolean SrvGroup_IsClient(Object paramObject);
  
  public native boolean SrvGroup_IsCommInterface(Object paramObject1, Object paramObject2);
  
  public native boolean SrvGroup_IsConnect(Object paramObject);
  
  public native boolean SrvGroup_IsDebug(Object paramObject);
  
  public native boolean SrvGroup_IsDefaultServer(Object paramObject);
  
  public native boolean SrvGroup_IsFunctionPara(Object paramObject1, Object paramObject2);
  
  public native boolean SrvGroup_IsInSync(Object paramObject);
  
  public native boolean SrvGroup_IsObject(Object paramObject1, Object paramObject2);
  
  public native boolean SrvGroup_IsParaPkg(Object paramObject1, Object paramObject2);
  
  public native boolean SrvGroup_IsQueryRecord(Object paramObject1, Object paramObject2);
  
  public native boolean SrvGroup_IsSXml(Object paramObject1, Object paramObject2);
  
  public native boolean SrvGroup_IsServer(Object paramObject);
  
  public native boolean SrvGroup_IsServerClient(Object paramObject);
  
  public native boolean SrvGroup_IsServiceSync(Object paramObject);
  
  public native boolean SrvGroup_IsWindowVisible(Object paramObject);
  
  public native void SrvGroup_KillTimer(Object paramObject, int paramInt);
  
  public native StarServiceClass SrvGroup_LoadService(Object paramObject, String paramString1, String paramString2, String paramString3, boolean paramBoolean);
  
  public native StarServiceClass SrvGroup_LoadServiceEx(Object paramObject, String paramString1, String paramString2, String paramString3, boolean paramBoolean);
  
  public native StarServiceClass SrvGroup_LoadServiceWithPath(Object paramObject, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean);
  
  public native boolean SrvGroup_LockLuaTable(Object paramObject);
  
  public native void SrvGroup_LuaEditDisp(Object paramObject, String paramString);
  
  public native void SrvGroup_LuaEditHelp(Object paramObject, int paramInt, String paramString);
  
  public native String SrvGroup_MD5(Object paramObject, String paramString);
  
  public native Object[] SrvGroup_MemorySize(Object paramObject);
  
  public native void SrvGroup_MessageBox(Object paramObject, String paramString1, String paramString2);
  
  public native void SrvGroup_MoveWindow(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean);
  
  public native StarBinBufClass SrvGroup_NewBinBuf(Object paramObject);
  
  public native StarCommInterfaceClass SrvGroup_NewCommInterface(Object paramObject);
  
  public native StarFunctionParaClass SrvGroup_NewFunctionPara(Object paramObject);
  
  public native StarParaPkgClass SrvGroup_NewParaPkg(Object paramObject);
  
  public native StarQueryRecordClass SrvGroup_NewQueryRecord(Object paramObject);
  
  public native StarSXmlClass SrvGroup_NewSXml(Object paramObject);
  
  public native Object[] SrvGroup_NextDoc(Object paramObject, StarQueryRecordClass paramStarQueryRecordClass);
  
  public native String SrvGroup_NextSearchPath(Object paramObject, StarQueryRecordClass paramStarQueryRecordClass);
  
  public native boolean SrvGroup_OpenLuaEdit(Object paramObject, String paramString, int paramInt, boolean paramBoolean);
  
  public native void SrvGroup_Print(Object paramObject, String paramString);
  
  public native void SrvGroup_PrintError(Object paramObject, int paramInt, String paramString);
  
  public native void SrvGroup_ProgramRestart(Object paramObject);
  
  public native Object[] SrvGroup_QuyeryStatistic(Object paramObject, int paramInt);
  
  public native void SrvGroup_RegDispatchCallBack(Object paramObject, String paramString);
  
  public native int SrvGroup_RegFileReqCallBack(Object paramObject, String paramString);
  
  public native void SrvGroup_RegWebDownFunction(Object paramObject, String paramString);
  
  public native void SrvGroup_RegisterDoc(Object paramObject1, Object paramObject2, String paramString);
  
  public native boolean SrvGroup_RegisterServer(Object paramObject, String paramString);
  
  public native int SrvGroup_RunFromUrl(Object paramObject, String paramString, int paramInt, boolean paramBoolean);
  
  public native boolean SrvGroup_RunScript(Object paramObject, String paramString1, String paramString2, String paramString3);
  
  public native boolean SrvGroup_RunScriptEx(Object paramObject, String paramString1, StarBinBufClass paramStarBinBufClass, String paramString2);
  
  public native int SrvGroup_SConnect(Object paramObject, String paramString1, String paramString2, int paramInt, String paramString3, String paramString4, StarParaPkgClass paramStarParaPkgClass);
  
  public native int SrvGroup_SConnectEx(Object paramObject, String paramString1, String paramString2, String paramString3, StarParaPkgClass paramStarParaPkgClass);
  
  public native boolean SrvGroup_ServicePathIsSet(Object paramObject);
  
  public native void SrvGroup_SetBkColor(Object paramObject, int paramInt);
  
  public native void SrvGroup_SetCaption(Object paramObject, String paramString);
  
  public native void SrvGroup_SetClientBkColor(Object paramObject, int paramInt);
  
  public native boolean SrvGroup_SetClientPort(Object paramObject, String paramString, int paramInt);
  
  public native void SrvGroup_SetClientSize(Object paramObject, int paramInt1, int paramInt2);
  
  public native void SrvGroup_SetColor(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public native void SrvGroup_SetCurrentPath(Object paramObject, String paramString);
  
  public native boolean SrvGroup_SetDataServerAddr(Object paramObject, boolean paramBoolean, String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2);
  
  public native boolean SrvGroup_SetDebugPort(Object paramObject, String paramString, int paramInt);
  
  public native void SrvGroup_SetEnvCurrentUrl(Object paramObject, String paramString);
  
  public native void SrvGroup_SetEnvPara(Object paramObject, StarParaPkgClass paramStarParaPkgClass);
  
  public native void SrvGroup_SetIdleActive(Object paramObject, boolean paramBoolean);
  
  public native boolean SrvGroup_SetOutputPort(Object paramObject, String paramString, int paramInt);
  
  public native void SrvGroup_SetServerPara(Object paramObject, int paramInt1, int paramInt2, int paramInt3);
  
  public native void SrvGroup_SetServicePath(Object paramObject, String paramString);
  
  public native boolean SrvGroup_SetTelnetPort(Object paramObject, int paramInt);
  
  public native int SrvGroup_SetTimer(Object paramObject, int paramInt1, String paramString, int paramInt2, int paramInt3);
  
  public native boolean SrvGroup_SetWebServerPort(Object paramObject, String paramString, int paramInt1, int paramInt2, int paramInt3);
  
  public native void SrvGroup_SetWindowStatus(Object paramObject, int paramInt);
  
  public native void SrvGroup_SetWindowStyle(Object paramObject, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5);
  
  public native int SrvGroup_SetupSocketClient(Object paramObject, String paramString1, String paramString2, int paramInt, String paramString3);
  
  public native int SrvGroup_SetupSocketServer(Object paramObject, String paramString1, int paramInt, String paramString2);
  
  public native void SrvGroup_ShowClientWnd(Object paramObject);
  
  public native void SrvGroup_ShowStatusMenu(Object paramObject, boolean paramBoolean1, boolean paramBoolean2);
  
  public native void SrvGroup_ShowWindow(Object paramObject);
  
  public native boolean SrvGroup_SocketSend(Object paramObject, int paramInt, StarParaPkgClass paramStarParaPkgClass, boolean paramBoolean);
  
  public native void SrvGroup_StartVSService(Object paramObject, String paramString);
  
  public native int SrvGroup_TickCount(Object paramObject);
  
  public native void SrvGroup_ToClipBoard(Object paramObject, String paramString);
  
  public native boolean SrvGroup_UnLockLuaTable(Object paramObject);
  
  public native void SrvGroup_UnRegFileReqCallBack(Object paramObject, int paramInt);
  
  public native void SrvGroup_UnRegisterDoc(Object paramObject1, Object paramObject2);
  
  public native boolean SrvGroup_WaitServiceSync(Object paramObject, int paramInt);
  
  public native void SrvGroup_WebServiceRefresh(Object paramObject);
  
  public native boolean SrvGroup_XmlToService(Object paramObject, StarSXmlClass paramStarSXmlClass, String paramString1, String paramString2, String paramString3);
  
  public native boolean SrvGroup_XmlToServiceEx(Object paramObject, String paramString1, String paramString2);
  
  public native boolean StarBinBuf_AnsiToUnicode(Object paramObject, String paramString, int paramInt);
  
  public native void StarBinBuf_Clear(Object paramObject);
  
  public native void StarBinBuf_ClearEx(Object paramObject, int paramInt1, int paramInt2);
  
  public native void StarBinBuf_CloseFile(Object paramObject, int paramInt);
  
  public native boolean StarBinBuf_Expand(Object paramObject, int paramInt);
  
  public native boolean StarBinBuf_Fill(Object paramObject, int paramInt1, int paramInt2, String paramString);
  
  public native int StarBinBuf_FindStr(Object paramObject, int paramInt, String paramString);
  
  public native int StarBinBuf_FindStri(Object paramObject, int paramInt, String paramString);
  
  public native Object StarBinBuf_Get(Object paramObject, int paramInt1, int paramInt2, String paramString);
  
  public native int StarBinBuf_GetFileSize(Object paramObject, int paramInt);
  
  public native int StarBinBuf_GetHash(Object paramObject);
  
  public native String StarBinBuf_GetMD5(Object paramObject);
  
  public native void StarBinBuf_Init(Object paramObject, int paramInt);
  
  public native void StarBinBuf_InsertStr(Object paramObject, int paramInt, String paramString);
  
  public native boolean StarBinBuf_IsLightBuf(Object paramObject);
  
  public native boolean StarBinBuf_LoadFromFile(Object paramObject, String paramString, boolean paramBoolean);
  
  public native int StarBinBuf_OpenFile(Object paramObject, String paramString1, String paramString2);
  
  public native boolean StarBinBuf_PackObject(Object paramObject, StarObjectClass paramStarObjectClass);
  
  public native void StarBinBuf_Print(Object paramObject, String paramString);
  
  public native int StarBinBuf_Read(Object paramObject, byte[] paramArrayOfByte, int paramInt1, int paramInt2);
  
  public native int StarBinBuf_Read2(Object paramObject, short[] paramArrayOfShort, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public native int StarBinBuf_Read4(Object paramObject, int[] paramArrayOfInt, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public native int StarBinBuf_ReadFile(Object paramObject, int paramInt1, int paramInt2, int paramInt3);
  
  public native boolean StarBinBuf_SaveToFile(Object paramObject, String paramString, boolean paramBoolean);
  
  public native int StarBinBuf_Set(Object paramObject1, int paramInt1, int paramInt2, String paramString, Object paramObject2);
  
  public native boolean StarBinBuf_SetOffset(Object paramObject, int paramInt);
  
  public native boolean StarBinBuf_ToAnsi(Object paramObject);
  
  public native boolean StarBinBuf_ToUTF8(Object paramObject);
  
  public native boolean StarBinBuf_UnPackObject(Object paramObject, StarObjectClass paramStarObjectClass);
  
  public native boolean StarBinBuf_UnicodeToAnsi(Object paramObject, String paramString, int paramInt);
  
  public native int StarBinBuf_Write(Object paramObject, int paramInt1, byte[] paramArrayOfByte, int paramInt2);
  
  public native int StarBinBuf_Write2(Object paramObject, int paramInt1, short[] paramArrayOfShort, int paramInt2, int paramInt3, int paramInt4);
  
  public native int StarBinBuf_Write4(Object paramObject, int paramInt1, int[] paramArrayOfInt, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public native int StarBinBuf_WriteFile(Object paramObject, int paramInt1, int paramInt2, int paramInt3);
  
  public native int StarBinBuf_WriteFromMemoryFile(Object paramObject, StarServiceClass paramStarServiceClass, int paramInt, String paramString);
  
  public native boolean StarCommInterface_BufDownLoad(Object paramObject, String paramString1, StarBinBufClass paramStarBinBufClass, boolean paramBoolean, String paramString2);
  
  public native boolean StarCommInterface_BufUpLoad(Object paramObject, String paramString1, StarBinBufClass paramStarBinBufClass1, String paramString2, StarBinBufClass paramStarBinBufClass2, boolean paramBoolean1, String paramString3, boolean paramBoolean2, String paramString4);
  
  public native boolean StarCommInterface_FileDownLoad(Object paramObject, String paramString1, String paramString2, boolean paramBoolean, String paramString3);
  
  public native boolean StarCommInterface_FileUpLoad(Object paramObject, String paramString1, String paramString2, String paramString3, StarBinBufClass paramStarBinBufClass, boolean paramBoolean1, String paramString4, boolean paramBoolean2, String paramString5);
  
  public native String StarCommInterface_FormatRspHeader(Object paramObject, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt);
  
  public native String StarCommInterface_FormatRspHeaderEx(Object paramObject, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt, String paramString5);
  
  public native String StarCommInterface_GetIP(Object paramObject, StarBinBufClass paramStarBinBufClass);
  
  public native int StarCommInterface_GetPort(Object paramObject, StarBinBufClass paramStarBinBufClass);
  
  public native boolean StarCommInterface_GetResponseBody(Object paramObject, StarBinBufClass paramStarBinBufClass1, StarBinBufClass paramStarBinBufClass2);
  
  public native Object[] StarCommInterface_GetResponseCode(Object paramObject, StarBinBufClass paramStarBinBufClass);
  
  public native int StarCommInterface_GetResponseLength(Object paramObject, StarBinBufClass paramStarBinBufClass);
  
  public native String StarCommInterface_GetResponseStr(Object paramObject, StarBinBufClass paramStarBinBufClass, String paramString);
  
  public native void StarCommInterface_HttpClearCookie(Object paramObject, String paramString1, String paramString2, String paramString3);
  
  public native int StarCommInterface_HttpDownLoad(Object paramObject, String paramString1, String paramString2);
  
  public native int StarCommInterface_HttpDownLoadEx(Object paramObject, String paramString1, String paramString2, String paramString3);
  
  public native String StarCommInterface_HttpGetHeaderItem(Object paramObject, String paramString1, int paramInt, String paramString2);
  
  public native String StarCommInterface_HttpGetHeaderSubItem(Object paramObject, String paramString1, int paramInt, String paramString2);
  
  public native String StarCommInterface_HttpGetMediaType(Object paramObject, String paramString);
  
  public native Object[] StarCommInterface_HttpGetMultiPart(Object paramObject, StarBinBufClass paramStarBinBufClass1, int paramInt1, int paramInt2, StarBinBufClass paramStarBinBufClass2);
  
  public native String StarCommInterface_HttpGetNVValue(Object paramObject, String paramString1, String paramString2);
  
  public native int StarCommInterface_HttpLocalRequest(Object paramObject, int paramInt, String paramString1, String paramString2, String paramString3, StarBinBufClass paramStarBinBufClass);
  
  public native int StarCommInterface_HttpLocalRequestEx(Object paramObject, String paramString);
  
  public native int StarCommInterface_HttpRecv(Object paramObject, int paramInt1, StarBinBufClass paramStarBinBufClass, int paramInt2);
  
  public native void StarCommInterface_HttpRelease(Object paramObject, int paramInt);
  
  public native int StarCommInterface_HttpSend(Object paramObject, int paramInt1, StarBinBufClass paramStarBinBufClass, int paramInt2, boolean paramBoolean);
  
  public native int StarCommInterface_HttpServer(Object paramObject, String paramString, int paramInt1, int paramInt2);
  
  public native void StarCommInterface_HttpSetCookie(Object paramObject, String paramString1, String paramString2, String paramString3, boolean paramBoolean);
  
  public native void StarCommInterface_HttpSetMaxPostSize(Object paramObject, int paramInt1, int paramInt2);
  
  public native StarTimeClass StarCommInterface_HttpTimeToTime(Object paramObject, String paramString);
  
  public native int StarCommInterface_HttpUpLoad(Object paramObject, String paramString1, String paramString2, int paramInt, String paramString3, boolean paramBoolean, String paramString4);
  
  public native int StarCommInterface_HttpUpLoadEx(Object paramObject, String paramString1, String paramString2, int paramInt, String paramString3);
  
  public native boolean StarCommInterface_IsHttpConnect(Object paramObject, int paramInt);
  
  public native boolean StarCommInterface_IsTCPConnect(Object paramObject, int paramInt);
  
  public native void StarCommInterface_KillTimer(Object paramObject, int paramInt);
  
  public native String StarCommInterface_ParsePara(Object paramObject, String paramString1, String paramString2);
  
  public native int StarCommInterface_SetupTimer(Object paramObject, int paramInt1, int paramInt2);
  
  public native int StarCommInterface_TCPRecv(Object paramObject, int paramInt1, StarBinBufClass paramStarBinBufClass, int paramInt2);
  
  public native int StarCommInterface_TCPRecvLine(Object paramObject, int paramInt, StarBinBufClass paramStarBinBufClass);
  
  public native void StarCommInterface_TCPRelease(Object paramObject, int paramInt);
  
  public native int StarCommInterface_TCPSend(Object paramObject, int paramInt1, StarBinBufClass paramStarBinBufClass, int paramInt2, boolean paramBoolean);
  
  public native int StarCommInterface_TCPSetupClient(Object paramObject, int paramInt1, String paramString, int paramInt2);
  
  public native int StarCommInterface_TCPSetupServer(Object paramObject, int paramInt1, String paramString, int paramInt2);
  
  public native String StarCommInterface_TimeToHttpTime(Object paramObject, StarTimeClass paramStarTimeClass);
  
  public native int StarCommInterface_UDPRecv(Object paramObject, int paramInt, StarBinBufClass paramStarBinBufClass1, StarBinBufClass paramStarBinBufClass2);
  
  public native void StarCommInterface_UDPRelease(Object paramObject, int paramInt);
  
  public native int StarCommInterface_UDPSend(Object paramObject, int paramInt, StarBinBufClass paramStarBinBufClass1, StarBinBufClass paramStarBinBufClass2);
  
  public native boolean StarCommInterface_UDPSetSockAddr(Object paramObject, String paramString, int paramInt, StarBinBufClass paramStarBinBufClass);
  
  public native int StarCommInterface_UDPSetupClient(Object paramObject, int paramInt);
  
  public native int StarCommInterface_UDPSetupServer(Object paramObject, int paramInt1, String paramString, int paramInt2);
  
  public native void StarCommInterface_WebServerRelease(Object paramObject, int paramInt);
  
  public native Object StarFunctionPara_Call(Object paramObject, StarObjectClass paramStarObjectClass, String paramString);
  
  public native void StarFunctionPara_Clear(Object paramObject);
  
  public native int StarFunctionPara_GetNumber(Object paramObject);
  
  public native Object StarFunctionPara_GetValue(Object paramObject, int paramInt);
  
  public native boolean StarFunctionPara_SetValue(Object paramObject1, int paramInt, Object paramObject2);
  
  public native void StarObject_ARemoteCall(Object paramObject, int paramInt1, int paramInt2, String paramString1, String paramString2, int paramInt3, Object... paramVarArgs);
  
  public native boolean StarObject_Active(Object paramObject);
  
  public native boolean StarObject_ActiveClient(Object paramObject, int paramInt);
  
  public native boolean StarObject_ActiveCmd(Object paramObject, int paramInt);
  
  public native void StarObject_AddFunction(Object paramObject1, Object paramObject2);
  
  public native Object StarObject_Call(Object paramObject, String paramString, Object... paramVarArgs);
  
  public native boolean StarObject_CanSetStaticData(Object paramObject, int paramInt);
  
  public native void StarObject_Change(Object paramObject1, String paramString, Object paramObject2);
  
  public native void StarObject_ChangeParent(Object paramObject, StarObjectClass paramStarObjectClass, String paramString);
  
  public native void StarObject_Copy(Object paramObject, StarObjectClass paramStarObjectClass);
  
  public native boolean StarObject_CreateFunc(Object paramObject, String paramString1, String paramString2);
  
  public native boolean StarObject_CreateFuncEx(Object paramObject, String paramString1, String paramString2);
  
  public native void StarObject_Deactive(Object paramObject);
  
  public native void StarObject_DeactiveClient(Object paramObject, int paramInt);
  
  public native void StarObject_DeferFree(Object paramObject);
  
  public native void StarObject_DeferLoadFromFile(Object paramObject, String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4);
  
  public native void StarObject_DelFromSDT(Object paramObject);
  
  public native void StarObject_DelFunc(Object paramObject, String paramString);
  
  public native void StarObject_E(Object paramObject);
  
  public native String StarObject_EventID(Object paramObject, String paramString);
  
  public native void StarObject_F(Object paramObject, String paramString);
  
  public native boolean StarObject_FillSoapRspHeader(Object paramObject, StarSXmlClass paramStarSXmlClass);
  
  public native Object[] StarObject_FirstActiveChild(Object paramObject);
  
  public native StarObjectClass StarObject_FirstInst(Object paramObject, StarQueryRecordClass paramStarQueryRecordClass);
  
  public native void StarObject_Free(Object paramObject);
  
  public native void StarObject_FreeNameValue(Object paramObject, String paramString);
  
  public native int StarObject_GetActiveCmd(Object paramObject);
  
  public native StarObjectClass StarObject_GetChild(Object paramObject, String paramString);
  
  public native StarObjectClass StarObject_GetChildByID(Object paramObject, String paramString, int paramInt);
  
  public native double StarObject_GetNameFloat(Object paramObject, String paramString, double paramDouble);
  
  public native int StarObject_GetNameInt(Object paramObject, String paramString, int paramInt);
  
  public native String StarObject_GetNameStr(Object paramObject, String paramString1, String paramString2);
  
  public native StarTimeClass StarObject_GetNameTime(Object paramObject, String paramString, StarTimeClass paramStarTimeClass);
  
  public native int StarObject_GetNameValueType(Object paramObject, String paramString);
  
  public native Object StarObject_GetPrivateValue(Object paramObject, int paramInt1, int paramInt2);
  
  public native Object StarObject_GetRemoteAttach(Object paramObject, String paramString);
  
  public native String StarObject_GetStaticData(Object paramObject, String paramString1, StarBinBufClass paramStarBinBufClass, String paramString2, boolean paramBoolean);
  
  public native void StarObject_Init(Object paramObject, String paramString);
  
  public native void StarObject_InsertToSDT(Object paramObject);
  
  public native boolean StarObject_IsActive(Object paramObject);
  
  public native boolean StarObject_IsChild(Object paramObject, StarObjectClass paramStarObjectClass);
  
  public native boolean StarObject_IsDirectInst(Object paramObject, StarObjectClass paramStarObjectClass);
  
  public native boolean StarObject_IsInActiveSet(Object paramObject);
  
  public native boolean StarObject_IsInFree(Object paramObject);
  
  public native boolean StarObject_IsInst(Object paramObject, StarObjectClass paramStarObjectClass);
  
  public native boolean StarObject_IsThisClient(Object paramObject);
  
  public native void StarObject_KillTimer(Object paramObject, int paramInt);
  
  public native boolean StarObject_LoadFromBuf(Object paramObject, StarBinBufClass paramStarBinBufClass, String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4);
  
  public native boolean StarObject_LoadFromFile(Object paramObject, String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4);
  
  public native void StarObject_LockGC(Object paramObject);
  
  public native void StarObject_MarkChange(Object paramObject, String paramString);
  
  public native void StarObject_NV(Object paramObject);
  
  public native StarObjectClass StarObject_New(Object paramObject, Object... paramVarArgs);
  
  public native StarObjectClass StarObject_NewClient(Object paramObject, Object... paramVarArgs);
  
  public native StarObjectClass StarObject_NewClientEx(Object paramObject, Object... paramVarArgs);
  
  public native StarObjectClass StarObject_NewEx(Object paramObject, Object... paramVarArgs);
  
  public native StarObjectClass StarObject_NewGlobal(Object paramObject, Object... paramVarArgs);
  
  public native StarObjectClass StarObject_NewGlobalEx(Object paramObject, Object... paramVarArgs);
  
  public native Object[] StarObject_NextActiveChild(Object paramObject, int paramInt);
  
  public native StarObjectClass StarObject_NextInst(Object paramObject, StarQueryRecordClass paramStarQueryRecordClass);
  
  public native void StarObject_PostProcessEvent(Object paramObject, String paramString, Object... paramVarArgs);
  
  public native Object[] StarObject_ProcessEvent(Object paramObject, String paramString, Object... paramVarArgs);
  
  public native void StarObject_QueryClose(Object paramObject, StarQueryRecordClass paramStarQueryRecordClass);
  
  public native StarObjectClass StarObject_QueryFirstActiveInst(Object paramObject, StarQueryRecordClass paramStarQueryRecordClass);
  
  public native StarObjectClass StarObject_QueryFirstInstFromSDT(Object paramObject, StarQueryRecordClass paramStarQueryRecordClass);
  
  public native StarObjectClass StarObject_QueryNextActiveInst(Object paramObject, StarQueryRecordClass paramStarQueryRecordClass);
  
  public native StarObjectClass StarObject_QueryNextInstFromSDT(Object paramObject, StarQueryRecordClass paramStarQueryRecordClass);
  
  public native int StarObject_RegEventFunction(Object paramObject, StarObjectClass paramStarObjectClass, String paramString1, String paramString2);
  
  public native int StarObject_RegFileCallBack(Object paramObject, String paramString);
  
  public native void StarObject_RemoteCall(Object paramObject, int paramInt, String paramString, Object... paramVarArgs);
  
  public native void StarObject_RemoteCallEx(Object paramObject, int paramInt, String paramString, Object... paramVarArgs);
  
  public native void StarObject_RemoteCallRsp(Object paramObject1, int paramInt1, int paramInt2, String paramString, int paramInt3, int paramInt4, Object[] paramArrayOfObject, int paramInt5, Object paramObject2);
  
  public native boolean StarObject_RemoteSend(Object paramObject, int paramInt, StarParaPkgClass paramStarParaPkgClass);
  
  public native void StarObject_ResetLoad(Object paramObject);
  
  public native void StarObject_S(Object paramObject, String paramString);
  
  public native void StarObject_SLockGC(Object paramObject);
  
  public native Object[] StarObject_SRemoteCall(Object paramObject, int paramInt1, int paramInt2, String paramString, Object... paramVarArgs);
  
  public native boolean StarObject_SaveToFile(Object paramObject, String paramString1, String paramString2, int paramInt, boolean paramBoolean);
  
  public native boolean StarObject_SaveToLuaFunc(Object paramObject, String paramString1, String paramString2);
  
  public native void StarObject_SetDeferRspFlag(Object paramObject);
  
  public native boolean StarObject_SetNameFloat(Object paramObject, String paramString, double paramDouble, boolean paramBoolean);
  
  public native boolean StarObject_SetNameInt(Object paramObject, String paramString, int paramInt, boolean paramBoolean);
  
  public native boolean StarObject_SetNameStr(Object paramObject, String paramString1, String paramString2, boolean paramBoolean);
  
  public native boolean StarObject_SetNameTime(Object paramObject, String paramString, StarTimeClass paramStarTimeClass, boolean paramBoolean);
  
  public native void StarObject_SetPrivateValue(Object paramObject1, int paramInt1, int paramInt2, Object paramObject2);
  
  public native void StarObject_SetRemoteRspAttach(Object paramObject, Object... paramVarArgs);
  
  public native void StarObject_SetRetCode(Object paramObject, int paramInt);
  
  public native String StarObject_SetStaticData(Object paramObject, String paramString, StarBinBufClass paramStarBinBufClass);
  
  public native String StarObject_SetStaticDataEx(Object paramObject, String paramString1, int paramInt1, int paramInt2, String paramString2);
  
  public native int StarObject_SetTimer(Object paramObject, int paramInt1, String paramString, int paramInt2, int paramInt3);
  
  public native void StarObject_UnLockGC(Object paramObject);
  
  public native void StarObject_UnRegEventFunction(Object paramObject, StarObjectClass paramStarObjectClass, String paramString, int paramInt);
  
  public native void StarObject_UnRegFileCallBack(Object paramObject, int paramInt);
  
  public native void StarObject_V(Object paramObject, String paramString);
  
  public native boolean StarObject_WaitGetStaticData(Object paramObject, String paramString1, String paramString2, boolean paramBoolean);
  
  public native boolean StarObject_WaitMalloc(Object paramObject);
  
  public native boolean StarObject_WaitSetStaticData(Object paramObject, String paramString1, String paramString2, boolean paramBoolean);
  
  public native boolean StarParaPkg_AppendFrom(Object paramObject, StarParaPkgClass paramStarParaPkgClass);
  
  public native void StarParaPkg_Clear(Object paramObject);
  
  public native void StarParaPkg_ClearChangeFlag(Object paramObject, int paramInt);
  
  public native void StarParaPkg_ClearChangeFlagEx(Object paramObject);
  
  public native boolean StarParaPkg_CopyBin(Object paramObject, int paramInt1, StarParaPkgClass paramStarParaPkgClass, int paramInt2);
  
  public native void StarParaPkg_Del(Object paramObject, int paramInt);
  
  public native boolean StarParaPkg_Exchange(Object paramObject, int paramInt1, int paramInt2);
  
  public native boolean StarParaPkg_FromDict(Object paramObject, Hashtable paramHashtable);
  
  public native boolean StarParaPkg_FromTuple(Object paramObject, Object[] paramArrayOfObject);
  
  public native Object StarParaPkg_Get(Object paramObject, int paramInt);
  
  public native int StarParaPkg_GetHash(Object paramObject, int paramInt);
  
  public native StarTimeClass StarParaPkg_GetTime(Object paramObject, int paramInt);
  
  public native String StarParaPkg_GetUUID(Object paramObject, int paramInt);
  
  public native boolean StarParaPkg_InsertEmpty(Object paramObject, int paramInt);
  
  public native boolean StarParaPkg_IsChangeFlag(Object paramObject, int paramInt);
  
  public native boolean StarParaPkg_IsChangeFlagEx(Object paramObject);
  
  public native boolean StarParaPkg_LoadChangeFromBuf(Object paramObject, StarBinBufClass paramStarBinBufClass);
  
  public native boolean StarParaPkg_LoadFromFile(Object paramObject, int paramInt, String paramString);
  
  public native boolean StarParaPkg_SaveChangeToBuf(Object paramObject, StarBinBufClass paramStarBinBufClass);
  
  public native boolean StarParaPkg_SaveChangeToBufEx(Object paramObject, StarBinBufClass paramStarBinBufClass);
  
  public native boolean StarParaPkg_SaveToFile(Object paramObject, int paramInt, String paramString);
  
  public native boolean StarParaPkg_Set(Object paramObject1, int paramInt, Object paramObject2);
  
  public native void StarParaPkg_SetChangeFlag(Object paramObject, int paramInt);
  
  public native void StarParaPkg_SetChangeFlagEx(Object paramObject);
  
  public native boolean StarParaPkg_SetTime(Object paramObject, int paramInt, StarTimeClass paramStarTimeClass);
  
  public native int StarParaPkg_T(Object paramObject, int paramInt);
  
  public native Hashtable StarParaPkg_ToDict(Object paramObject);
  
  public native Object[] StarParaPkg_ToTuple(Object paramObject);
  
  public native boolean StarSXml_CopyChild(Object paramObject, int paramInt1, int paramInt2);
  
  public native int StarSXml_CopyElementAfter(Object paramObject, int paramInt1, int paramInt2, int paramInt3);
  
  public native int StarSXml_CopyElementBefore(Object paramObject, int paramInt1, int paramInt2, int paramInt3);
  
  public native boolean StarSXml_Dup(Object paramObject, StarSXmlClass paramStarSXmlClass);
  
  public native int StarSXml_FindAttribute(Object paramObject, int paramInt, String paramString);
  
  public native int StarSXml_FindElement(Object paramObject, String paramString);
  
  public native int StarSXml_FindElementEx(Object paramObject, int paramInt, String paramString);
  
  public native int StarSXml_FirstAttribute(Object paramObject, int paramInt);
  
  public native int StarSXml_FirstElement(Object paramObject, int paramInt);
  
  public native int StarSXml_FirstText(Object paramObject, int paramInt);
  
  public native String StarSXml_GetAttributeName(Object paramObject, int paramInt);
  
  public native String StarSXml_GetAttributeValue(Object paramObject, int paramInt);
  
  public native String StarSXml_GetElement(Object paramObject, int paramInt);
  
  public native String StarSXml_GetElementEx(Object paramObject, int paramInt);
  
  public native String StarSXml_GetEncoding(Object paramObject);
  
  public native Object[] StarSXml_GetNs(Object paramObject, int paramInt);
  
  public native String StarSXml_GetNsValue(Object paramObject, int paramInt, String paramString);
  
  public native String StarSXml_GetSingleText(Object paramObject, int paramInt);
  
  public native String StarSXml_GetStandalone(Object paramObject);
  
  public native String StarSXml_GetText(Object paramObject, int paramInt);
  
  public native String StarSXml_GetVersion(Object paramObject);
  
  public native int StarSXml_InsertCommentAfter(Object paramObject, int paramInt1, int paramInt2, String paramString);
  
  public native int StarSXml_InsertCommentBefore(Object paramObject, int paramInt1, int paramInt2, String paramString);
  
  public native int StarSXml_InsertElementAfter(Object paramObject, int paramInt1, int paramInt2, String paramString);
  
  public native int StarSXml_InsertElementBefore(Object paramObject, int paramInt1, int paramInt2, String paramString);
  
  public native int StarSXml_InsertTextAfter(Object paramObject, int paramInt1, int paramInt2, String paramString, boolean paramBoolean);
  
  public native int StarSXml_InsertTextBefore(Object paramObject, int paramInt1, int paramInt2, String paramString, boolean paramBoolean);
  
  public native Object[] StarSXml_LoadFromBuf(Object paramObject, StarBinBufClass paramStarBinBufClass);
  
  public native Object[] StarSXml_LoadFromBufEx(Object paramObject, String paramString);
  
  public native Object[] StarSXml_LoadFromFile(Object paramObject, String paramString);
  
  public native int StarSXml_NextAttribute(Object paramObject, int paramInt);
  
  public native int StarSXml_NextElement(Object paramObject, int paramInt);
  
  public native int StarSXml_NextText(Object paramObject, int paramInt);
  
  public native int StarSXml_ParentElement(Object paramObject, int paramInt);
  
  public native void StarSXml_RemoveAttribute(Object paramObject, int paramInt, String paramString);
  
  public native void StarSXml_RemoveComment(Object paramObject, int paramInt);
  
  public native void StarSXml_RemoveDeclaration(Object paramObject);
  
  public native void StarSXml_RemoveElement(Object paramObject, int paramInt);
  
  public native void StarSXml_RemoveText(Object paramObject, int paramInt);
  
  public native boolean StarSXml_SaveToBuf(Object paramObject, StarBinBufClass paramStarBinBufClass);
  
  public native boolean StarSXml_SaveToFile(Object paramObject, String paramString);
  
  public native void StarSXml_SetAttribute(Object paramObject, int paramInt, String paramString1, String paramString2);
  
  public native void StarSXml_SetComment(Object paramObject, int paramInt, String paramString);
  
  public native void StarSXml_SetDeclaration(Object paramObject, String paramString1, String paramString2, String paramString3);
  
  public native void StarSXml_SetElement(Object paramObject, int paramInt, String paramString);
  
  public native void StarSXml_SetNs(Object paramObject, int paramInt, String paramString1, String paramString2);
  
  public native void StarSXml_SetText(Object paramObject, int paramInt, String paramString, boolean paramBoolean);
  
  public native Object[] StarServiceItem_GetActiveSet(Object paramObject);
  
  public native int StarServiceItem_GetGroupSyncStatus(Object paramObject, int paramInt);
  
  public native boolean StarServiceItem_IsSync(Object paramObject);
  
  public native StarObjectClass StarServiceItem_QueryFirstGroupObject(Object paramObject, int paramInt);
  
  public native StarObjectClass StarServiceItem_QueryNextGroupObject(Object paramObject);
  
  public native void StarServiceItem_SetActiveSet(Object paramObject, Object... paramVarArgs);
  
  public native void StarServiceItem_SetClientActiveSet(Object paramObject, int paramInt, Object... paramVarArgs);
  
  public native boolean StarServiceItem_WaitSync(Object paramObject);
  
  public native boolean StarService_AcceptClient(Object paramObject, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2, int paramInt2, int paramInt3, int paramInt4);
  
  public native void StarService_ActiveAllSysRootItem(Object paramObject);
  
  public native void StarService_ActiveCSysRootItem(Object paramObject, int paramInt, String paramString);
  
  public native void StarService_ActiveSysRootItem(Object paramObject, String paramString);
  
  public native boolean StarService_ApplyLog(Object paramObject);
  
  public native boolean StarService_AtomicAttach(Object paramObject, int paramInt, String paramString);
  
  public native StarObjectClass StarService_AtomicToObject(Object paramObject, int paramInt);
  
  public native void StarService_CheckPassword(Object paramObject, boolean paramBoolean);
  
  public native void StarService_ClearLog(Object paramObject);
  
  public native void StarService_ClearStatic(Object paramObject, int paramInt);
  
  public native int StarService_CreateAtomicAttachAttribute(Object paramObject, int paramInt1, String paramString1, String paramString2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, String paramString3, String paramString4);
  
  public native int StarService_CreateAtomicAttribute(Object paramObject, int paramInt1, String paramString1, String paramString2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, String paramString3, String paramString4);
  
  public native int StarService_CreateAtomicDepend(Object paramObject, String paramString);
  
  public native int StarService_CreateAtomicEditModule(Object paramObject, String paramString1, String paramString2);
  
  public native int StarService_CreateAtomicFuncParaAttribute(Object paramObject, int paramInt1, String paramString1, String paramString2, int paramInt2, String paramString3);
  
  public native int StarService_CreateAtomicFuncRetAttribute(Object paramObject, int paramInt1, int paramInt2, String paramString);
  
  public native int StarService_CreateAtomicFunction(Object paramObject, int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4);
  
  public native Object[] StarService_CreateAtomicFunctionEx(Object paramObject, int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2, String paramString4, boolean paramBoolean3, boolean paramBoolean4);
  
  public native Object[] StarService_CreateAtomicFunctionSimple(Object paramObject, int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2);
  
  public native int StarService_CreateAtomicInEvent(Object paramObject, int paramInt, String paramString1, String paramString2, String paramString3);
  
  public native int StarService_CreateAtomicLuaFunction(Object paramObject, int paramInt, String paramString1, String paramString2, String paramString3);
  
  public native int StarService_CreateAtomicMacro(Object paramObject, String paramString, int paramInt);
  
  public native int StarService_CreateAtomicMacroItem(Object paramObject, int paramInt, String paramString1, String paramString2);
  
  public native int StarService_CreateAtomicModule(Object paramObject, String paramString1, int paramInt, String paramString2);
  
  public native int StarService_CreateAtomicObject(Object paramObject, int paramInt1, String paramString1, int paramInt2, String paramString2, String paramString3);
  
  public native Object[] StarService_CreateAtomicObjectAttributeSimple(Object paramObject, int paramInt, String paramString);
  
  public native Object[] StarService_CreateAtomicObjectSimple(Object paramObject, String paramString1, String paramString2, String paramString3, String paramString4);
  
  public native int StarService_CreateAtomicOutEvent(Object paramObject, int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean);
  
  public native int StarService_CreateAtomicOvlFunction(Object paramObject, int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean);
  
  public native int StarService_CreateAtomicScript(Object paramObject, int paramInt, String paramString1, String paramString2, String paramString3, String paramString4);
  
  public native int StarService_CreateAtomicStruct(Object paramObject, String paramString1, String paramString2, String paramString3);
  
  public native int StarService_CreateAtomicStructAttribute(Object paramObject, int paramInt1, String paramString1, String paramString2, int paramInt2, String paramString3);
  
  public native Object[] StarService_CreateAtomicStructSimple(Object paramObject, String paramString1, String paramString2, String paramString3);
  
  public native int StarService_CreateAtomicSysRootItem(Object paramObject, String paramString1, String paramString2);
  
  public native boolean StarService_CreateSysRootItem(Object paramObject, String paramString1, String paramString2, String paramString3, String paramString4);
  
  public native StarServiceItemClass StarService_CreateSysRootItemEx(Object paramObject, String paramString1, String paramString2, String paramString3, String paramString4);
  
  public native boolean StarService_CreateUser(Object paramObject, String paramString1, String paramString2, int paramInt);
  
  public native void StarService_DeactiveAll(Object paramObject);
  
  public native void StarService_DeactiveCSysRootItem(Object paramObject, int paramInt, String paramString);
  
  public native void StarService_DeactiveSysRootItem(Object paramObject, String paramString);
  
  public native void StarService_DelClient(Object paramObject, int paramInt);
  
  public native void StarService_DeleteUser(Object paramObject, String paramString);
  
  public native Object[] StarService_DoFile(Object paramObject, String paramString1, String paramString2, String paramString3);
  
  public native void StarService_DownLoad(Object paramObject, String paramString1, String paramString2, String paramString3);
  
  public native void StarService_Exit(Object paramObject);
  
  public native Object[] StarService_ExportModule(Object paramObject, String paramString);
  
  public native Object[] StarService_FirstUser(Object paramObject, StarQueryRecordClass paramStarQueryRecordClass);
  
  public native void StarService_ForceToSaveStatic(Object paramObject);
  
  public native String StarService_GetAtomicID(Object paramObject, int paramInt);
  
  public native int StarService_GetAtomicObjectEx(Object paramObject, int paramInt, String paramString);
  
  public native int StarService_GetAtomicSysRootItem(Object paramObject, String paramString);
  
  public native Object[] StarService_GetClientInfo(Object paramObject, int paramInt);
  
  public native int StarService_GetClientNumber(Object paramObject);
  
  public native StarObjectClass StarService_GetClientObject(Object paramObject);
  
  public native String StarService_GetLogFile(Object paramObject);
  
  public native int StarService_GetOPPermission(Object paramObject);
  
  public native StarObjectClass StarService_GetObject(Object paramObject, String paramString);
  
  public native StarObjectClass StarService_GetObjectEx(Object paramObject, String paramString);
  
  public native StarObjectClass StarService_GetObjectEx2(Object paramObject, String paramString1, String paramString2);
  
  public native StarObjectClass StarService_GetObjectFromLua(Object paramObject, String paramString);
  
  public native String StarService_GetPeerIP(Object paramObject, int paramInt);
  
  public native int StarService_GetServerID(Object paramObject);
  
  public native StarServiceItemClass StarService_GetSysRootItem(Object paramObject, String paramString);
  
  public native void StarService_HttpDownLoad(Object paramObject, String paramString1, String paramString2, String paramString3);
  
  public native void StarService_HttpDownLoadAbort(Object paramObject);
  
  public native boolean StarService_IsActive(Object paramObject);
  
  public native boolean StarService_IsChange(Object paramObject);
  
  public native boolean StarService_IsOsSupport(Object paramObject, int paramInt1, int paramInt2);
  
  public native boolean StarService_IsServiceRegistered(Object paramObject);
  
  public native StarObjectClass StarService_New(Object paramObject, Object... paramVarArgs);
  
  public native StarObjectClass StarService_NewClient(Object paramObject, Object... paramVarArgs);
  
  public native StarObjectClass StarService_NewClientEx(Object paramObject, Object... paramVarArgs);
  
  public native StarObjectClass StarService_NewEx(Object paramObject, Object... paramVarArgs);
  
  public native StarObjectClass StarService_NewGlobal(Object paramObject, Object... paramVarArgs);
  
  public native StarObjectClass StarService_NewGlobalEx(Object paramObject, Object... paramVarArgs);
  
  public native Object[] StarService_NextUser(Object paramObject, StarQueryRecordClass paramStarQueryRecordClass);
  
  public native int StarService_ObjectToAtomic(Object paramObject, StarObjectClass paramStarObjectClass);
  
  public native boolean StarService_ObjectToXml(Object paramObject1, StarSXmlClass paramStarSXmlClass, Object paramObject2, String paramString1, boolean paramBoolean1, boolean paramBoolean2, String paramString2);
  
  public native void StarService_PackStaticData(Object paramObject);
  
  public native void StarService_PrintClientInfo(Object paramObject);
  
  public native void StarService_PrintInfo(Object paramObject);
  
  public native void StarService_PrintMacro(Object paramObject, String paramString);
  
  public native Object[] StarService_QueryFirstDepend(Object paramObject);
  
  public native StarObjectClass StarService_QueryFirstFromSDT(Object paramObject);
  
  public native String StarService_QueryFirstSysRootItem(Object paramObject);
  
  public native Object[] StarService_QueryNextDepend(Object paramObject);
  
  public native StarObjectClass StarService_QueryNextFromSDT(Object paramObject);
  
  public native String StarService_QueryNextSysRootItem(Object paramObject);
  
  public native void StarService_Redirect(Object paramObject, int paramInt1, String paramString1, String paramString2, int paramInt2, StarParaPkgClass paramStarParaPkgClass, String paramString3);
  
  public native void StarService_RegClientOpFunction(Object paramObject, String paramString);
  
  public native int StarService_RegFileCallBack(Object paramObject, String paramString);
  
  public native void StarService_RegMachineFunction(Object paramObject, String paramString);
  
  public native void StarService_RegServerWebDownFunction(Object paramObject, String paramString);
  
  public native Object[] StarService_RunScript(Object paramObject, String paramString1, String paramString2, String paramString3, String paramString4);
  
  public native Object[] StarService_RunScriptEx(Object paramObject, String paramString1, StarBinBufClass paramStarBinBufClass, String paramString2, String paramString3);
  
  public native void StarService_Save(Object paramObject, String paramString);
  
  public native boolean StarService_ServiceToXml(Object paramObject, StarSXmlClass paramStarSXmlClass, String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, String paramString3);
  
  public native boolean StarService_SetAtomicAttributeCombobox(Object paramObject, int paramInt, String paramString);
  
  public native boolean StarService_SetAtomicAttributeLength(Object paramObject, int paramInt1, int paramInt2);
  
  public native boolean StarService_SetAtomicAttributeStruct(Object paramObject, int paramInt1, int paramInt2);
  
  public native boolean StarService_SetAtomicAttributeSyncFlag(Object paramObject, int paramInt1, int paramInt2);
  
  public native boolean StarService_SetAtomicObjectAttribute(Object paramObject, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4);
  
  public native boolean StarService_SetAtomicObjectSyncGroup(Object paramObject, int paramInt1, int paramInt2);
  
  public native boolean StarService_SetClientObject(Object paramObject, int paramInt, StarObjectClass paramStarObjectClass);
  
  public native void StarService_SetLog(Object paramObject1, Object paramObject2, boolean paramBoolean);
  
  public native void StarService_SetLogFile(Object paramObject, String paramString);
  
  public native void StarService_SetPrivateTag(Object paramObject, int paramInt);
  
  public native boolean StarService_SysRootItemToXml(Object paramObject, StarSXmlClass paramStarSXmlClass, String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, String paramString3);
  
  public native void StarService_UnRegFileCallBack(Object paramObject, int paramInt);
  
  public native void StarService_UpLoad(Object paramObject, String paramString1, String paramString2, String paramString3);
  
  public native boolean StarService_XmlToObject(Object paramObject1, StarSXmlClass paramStarSXmlClass, Object paramObject2, String paramString1, String paramString2, String paramString3, String paramString4);
  
  public native boolean StarService_XmlToSysRootItem(Object paramObject, StarSXmlClass paramStarSXmlClass, String paramString1, String paramString2, String paramString3);
  
  public native StarSrvGroupClass _CreateSrvGroup(int paramInt1, int paramInt2);
  
  public native void _DeleteSrvGroup(int paramInt);
  
  public native void _FindClose(Object paramObject);
  
  public native Object[] _FindFirstFile(String paramString);
  
  public native Object[] _FindNextFile(Object paramObject);
  
  public native int _FindWindow(String paramString);
  
  public native int _FirstSrvGroup();
  
  public native Object _Get(String paramString);
  
  public native Boolean _GetBool(String paramString);
  
  public native Double _GetDouble(String paramString);
  
  public native Integer _GetInt(String paramString);
  
  public native boolean _GetKeyState(int paramInt);
  
  public native String _GetLocale();
  
  public native int _GetOsType();
  
  public native int _GetProgramType();
  
  public native int _GetRegInt(String paramString1, String paramString2, int paramInt);
  
  public native String _GetRegStr(String paramString1, String paramString2, String paramString3);
  
  public native String _GetRootUrl();
  
  public native StarSrvGroupClass _GetSrvGroup(Object paramObject);
  
  public native String _GetStr(String paramString);
  
  public native String _GetSysPath();
  
  public native String _GetSystemRegCode();
  
  public native String _GetUrl();
  
  public native boolean _Getbool(String paramString);
  
  public native double _Getdouble(String paramString);
  
  public native int _Getint(String paramString);
  
  public native String _IDToMD5(String paramString);
  
  public native int _InitCore(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, String paramString1, int paramInt1, String paramString2, int paramInt2);
  
  public native void _InitObject(Object paramObject, Object[] paramArrayOfObject);
  
  public native StarServiceClass _InitSimple(String paramString1, String paramString2, int paramInt1, int paramInt2, String... paramVarArgs);
  
  public native StarServiceClass _InitSimple1(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2, String... paramVarArgs);
  
  public native StarSrvGroupClass _InitSimpleEx(int paramInt1, int paramInt2, String... paramVarArgs);
  
  public native int _IntComp(int paramInt1, int paramInt2);
  
  public native boolean _IsRegistered();
  
  public native int _KeyPress();
  
  public native void _ModuleClear();
  
  public native void _ModuleExit();
  
  public native boolean _MsgLoop(StarCallBackClass paramStarCallBackClass, Object paramObject);
  
  public native int _NextSrvGroup();
  
  public native boolean _PreAuthorize(String paramString1, String paramString2, String paramString3, boolean paramBoolean);
  
  public native void _RegMsgCallBack(StarCallBackClass paramStarCallBackClass, String paramString);
  
  public native boolean _SRPDispatch(boolean paramBoolean);
  
  public native boolean _SRPIdle();
  
  public native void _SRPLock();
  
  public native void _SRPUnLock();
  
  public native void _Set(String paramString, Object paramObject);
  
  public native void _SetLocale(String paramString);
  
  public native void _SetLogFile(String paramString, boolean paramBoolean);
  
  public native void _SetProgramType(int paramInt);
  
  public native boolean _SetRegisterCode(String paramString, boolean paramBoolean);
  
  public native void _ShellExecute(String paramString1, String paramString2);
  
  public native void _SrvGroupInfo();
  
  public native void _TermObject(Object paramObject);
  
  public native StarTimeClass _Time();
  
  public native boolean _Tobool(Object paramObject);
  
  public native double _Todouble(Object paramObject);
  
  public native int _Toint(Object paramObject);
  
  public native int _UIntComp(int paramInt1, int paramInt2);
  
  public native String _UuidCreate();
  
  public native int[] _Version();
  
  public native boolean _WinMsgDispatch();
  
  public native void _WrapObject(Object paramObject1, Object paramObject2);
  
  public native int _and32(int paramInt1, int paramInt2);
  
  public native int _htonl(int paramInt);
  
  public native short _htons(short paramShort);
  
  public native int _ntohl(int paramInt);
  
  public native short _ntohs(short paramShort);
  
  public native int _or32(int paramInt1, int paramInt2);
  
  public native int _shl32(int paramInt1, int paramInt2);
  
  public native int _shr32(int paramInt1, int paramInt2);
  
  public native int _strchr(String paramString1, String paramString2);
  
  public native int _strrchr(String paramString1, String paramString2);
  
  public native int _xor32(int paramInt1, int paramInt2);
  
  protected void finalize()
  {
    _TermObject(this);
  }
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srplab/www/starcore/StarCoreFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */