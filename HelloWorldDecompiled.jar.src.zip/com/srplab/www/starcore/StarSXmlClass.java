package com.srplab.www.starcore;

public class StarSXmlClass
{
  private StarCoreFactory StarCore;
  private int m_Handle;
  
  private StarSXmlClass(StarCoreFactory paramStarCoreFactory, Object[] paramArrayOfObject)
  {
    this.StarCore = paramStarCoreFactory;
    this.StarCore._InitObject(this, paramArrayOfObject);
  }
  
  public boolean _CopyChild(int paramInt1, int paramInt2)
  {
    return this.StarCore.StarSXml_CopyChild(this, paramInt1, paramInt2);
  }
  
  public int _CopyElementAfter(int paramInt1, int paramInt2, int paramInt3)
  {
    return this.StarCore.StarSXml_CopyElementAfter(this, paramInt1, paramInt2, paramInt3);
  }
  
  public int _CopyElementBefore(int paramInt1, int paramInt2, int paramInt3)
  {
    return this.StarCore.StarSXml_CopyElementBefore(this, paramInt1, paramInt2, paramInt3);
  }
  
  public boolean _Dup(StarSXmlClass paramStarSXmlClass)
  {
    return this.StarCore.StarSXml_Dup(this, paramStarSXmlClass);
  }
  
  public int _FindAttribute(int paramInt, String paramString)
  {
    return this.StarCore.StarSXml_FindAttribute(this, paramInt, paramString);
  }
  
  public int _FindElement(String paramString)
  {
    return this.StarCore.StarSXml_FindElement(this, paramString);
  }
  
  public int _FindElementEx(int paramInt, String paramString)
  {
    return this.StarCore.StarSXml_FindElementEx(this, paramInt, paramString);
  }
  
  public int _FirstAttribute(int paramInt)
  {
    return this.StarCore.StarSXml_FirstAttribute(this, paramInt);
  }
  
  public int _FirstElement(int paramInt)
  {
    return this.StarCore.StarSXml_FirstElement(this, paramInt);
  }
  
  public int _FirstText(int paramInt)
  {
    return this.StarCore.StarSXml_FirstText(this, paramInt);
  }
  
  public Object _Get(String paramString)
  {
    return this.StarCore.Common_Get(this, paramString);
  }
  
  public String _GetAttributeName(int paramInt)
  {
    return this.StarCore.StarSXml_GetAttributeName(this, paramInt);
  }
  
  public String _GetAttributeValue(int paramInt)
  {
    return this.StarCore.StarSXml_GetAttributeValue(this, paramInt);
  }
  
  public Boolean _GetBool(String paramString)
  {
    return this.StarCore.Common_GetBool(this, paramString);
  }
  
  public Double _GetDouble(String paramString)
  {
    return this.StarCore.Common_GetDouble(this, paramString);
  }
  
  public String _GetElement(int paramInt)
  {
    return this.StarCore.StarSXml_GetElement(this, paramInt);
  }
  
  public String _GetElementEx(int paramInt)
  {
    return this.StarCore.StarSXml_GetElementEx(this, paramInt);
  }
  
  public String _GetEncoding()
  {
    return this.StarCore.StarSXml_GetEncoding(this);
  }
  
  public Integer _GetInt(String paramString)
  {
    return this.StarCore.Common_GetInt(this, paramString);
  }
  
  public Object[] _GetNs(int paramInt)
  {
    return this.StarCore.StarSXml_GetNs(this, paramInt);
  }
  
  public String _GetNsValue(int paramInt, String paramString)
  {
    return this.StarCore.StarSXml_GetNsValue(this, paramInt, paramString);
  }
  
  public String _GetSingleText(int paramInt)
  {
    return this.StarCore.StarSXml_GetSingleText(this, paramInt);
  }
  
  public String _GetStandalone()
  {
    return this.StarCore.StarSXml_GetStandalone(this);
  }
  
  public String _GetStr(String paramString)
  {
    return this.StarCore.Common_GetStr(this, paramString);
  }
  
  public String _GetText(int paramInt)
  {
    return this.StarCore.StarSXml_GetText(this, paramInt);
  }
  
  public String _GetVersion()
  {
    return this.StarCore.StarSXml_GetVersion(this);
  }
  
  public boolean _Getbool(String paramString)
  {
    return this.StarCore.Common_Getbool(this, paramString);
  }
  
  public double _Getdouble(String paramString)
  {
    return this.StarCore.Common_Getdouble(this, paramString);
  }
  
  public int _Getint(String paramString)
  {
    return this.StarCore.Common_Getint(this, paramString);
  }
  
  public int _InsertCommentAfter(int paramInt1, int paramInt2, String paramString)
  {
    return this.StarCore.StarSXml_InsertCommentAfter(this, paramInt1, paramInt2, paramString);
  }
  
  public int _InsertCommentBefore(int paramInt1, int paramInt2, String paramString)
  {
    return this.StarCore.StarSXml_InsertCommentBefore(this, paramInt1, paramInt2, paramString);
  }
  
  public int _InsertElementAfter(int paramInt1, int paramInt2, String paramString)
  {
    return this.StarCore.StarSXml_InsertElementAfter(this, paramInt1, paramInt2, paramString);
  }
  
  public int _InsertElementBefore(int paramInt1, int paramInt2, String paramString)
  {
    return this.StarCore.StarSXml_InsertElementBefore(this, paramInt1, paramInt2, paramString);
  }
  
  public int _InsertTextAfter(int paramInt1, int paramInt2, String paramString, boolean paramBoolean)
  {
    return this.StarCore.StarSXml_InsertTextAfter(this, paramInt1, paramInt2, paramString, paramBoolean);
  }
  
  public int _InsertTextBefore(int paramInt1, int paramInt2, String paramString, boolean paramBoolean)
  {
    return this.StarCore.StarSXml_InsertTextBefore(this, paramInt1, paramInt2, paramString, paramBoolean);
  }
  
  public Object[] _LoadFromBuf(StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.StarSXml_LoadFromBuf(this, paramStarBinBufClass);
  }
  
  public Object[] _LoadFromBufEx(String paramString)
  {
    return this.StarCore.StarSXml_LoadFromBufEx(this, paramString);
  }
  
  public Object[] _LoadFromFile(String paramString)
  {
    return this.StarCore.StarSXml_LoadFromFile(this, paramString);
  }
  
  public int _NextAttribute(int paramInt)
  {
    return this.StarCore.StarSXml_NextAttribute(this, paramInt);
  }
  
  public int _NextElement(int paramInt)
  {
    return this.StarCore.StarSXml_NextElement(this, paramInt);
  }
  
  public int _NextText(int paramInt)
  {
    return this.StarCore.StarSXml_NextText(this, paramInt);
  }
  
  public int _ParentElement(int paramInt)
  {
    return this.StarCore.StarSXml_ParentElement(this, paramInt);
  }
  
  public void _RemoveAttribute(int paramInt, String paramString)
  {
    this.StarCore.StarSXml_RemoveAttribute(this, paramInt, paramString);
  }
  
  public void _RemoveComment(int paramInt)
  {
    this.StarCore.StarSXml_RemoveComment(this, paramInt);
  }
  
  public void _RemoveDeclaration()
  {
    this.StarCore.StarSXml_RemoveDeclaration(this);
  }
  
  public void _RemoveElement(int paramInt)
  {
    this.StarCore.StarSXml_RemoveElement(this, paramInt);
  }
  
  public void _RemoveText(int paramInt)
  {
    this.StarCore.StarSXml_RemoveText(this, paramInt);
  }
  
  public boolean _SaveToBuf(StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.StarSXml_SaveToBuf(this, paramStarBinBufClass);
  }
  
  public boolean _SaveToFile(String paramString)
  {
    return this.StarCore.StarSXml_SaveToFile(this, paramString);
  }
  
  public void _Set(String paramString, Object paramObject)
  {
    this.StarCore.Common_Set(this, paramString, paramObject);
  }
  
  public void _SetAttribute(int paramInt, String paramString1, String paramString2)
  {
    this.StarCore.StarSXml_SetAttribute(this, paramInt, paramString1, paramString2);
  }
  
  public void _SetComment(int paramInt, String paramString)
  {
    this.StarCore.StarSXml_SetComment(this, paramInt, paramString);
  }
  
  public void _SetDeclaration(String paramString1, String paramString2, String paramString3)
  {
    this.StarCore.StarSXml_SetDeclaration(this, paramString1, paramString2, paramString3);
  }
  
  public void _SetElement(int paramInt, String paramString)
  {
    this.StarCore.StarSXml_SetElement(this, paramInt, paramString);
  }
  
  public void _SetNs(int paramInt, String paramString1, String paramString2)
  {
    this.StarCore.StarSXml_SetNs(this, paramInt, paramString1, paramString2);
  }
  
  public void _SetText(int paramInt, String paramString, boolean paramBoolean)
  {
    this.StarCore.StarSXml_SetText(this, paramInt, paramString, paramBoolean);
  }
  
  public boolean _Tobool(Object paramObject)
  {
    return this.StarCore.Common_Tobool(this, paramObject);
  }
  
  public double _Todouble(Object paramObject)
  {
    return this.StarCore.Common_Todouble(this, paramObject);
  }
  
  public int _Toint(Object paramObject)
  {
    return this.StarCore.Common_Toint(this, paramObject);
  }
  
  protected void finalize()
  {
    this.StarCore._TermObject(this);
  }
  
  public String toString()
  {
    return this.StarCore.Common_toString(this);
  }
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srplab/www/starcore/StarSXmlClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */