package com.srplab.www.starcore;

public class StarCommInterfaceClass
{
  private StarCoreFactory StarCore;
  private int m_Handle;
  
  public StarCommInterfaceClass() {}
  
  public StarCommInterfaceClass(StarCommInterfaceClass paramStarCommInterfaceClass)
  {
    this.StarCore = paramStarCommInterfaceClass.StarCore;
    this.StarCore._WrapObject(this, paramStarCommInterfaceClass);
  }
  
  private StarCommInterfaceClass(StarCoreFactory paramStarCoreFactory, Object[] paramArrayOfObject)
  {
    this.StarCore = paramStarCoreFactory;
    this.StarCore._InitObject(this, paramArrayOfObject);
  }
  
  public StarCommInterfaceClass _Assign(StarCommInterfaceClass paramStarCommInterfaceClass)
  {
    paramStarCommInterfaceClass.StarCore = this.StarCore;
    this.StarCore._WrapObject(paramStarCommInterfaceClass, this);
    return paramStarCommInterfaceClass;
  }
  
  public boolean _BufDownLoad(String paramString1, StarBinBufClass paramStarBinBufClass, boolean paramBoolean, String paramString2)
  {
    return this.StarCore.StarCommInterface_BufDownLoad(this, paramString1, paramStarBinBufClass, paramBoolean, paramString2);
  }
  
  public boolean _BufUpLoad(String paramString1, StarBinBufClass paramStarBinBufClass1, String paramString2, StarBinBufClass paramStarBinBufClass2, boolean paramBoolean1, String paramString3, boolean paramBoolean2, String paramString4)
  {
    return this.StarCore.StarCommInterface_BufUpLoad(this, paramString1, paramStarBinBufClass1, paramString2, paramStarBinBufClass2, paramBoolean1, paramString3, paramBoolean2, paramString4);
  }
  
  public boolean _FileDownLoad(String paramString1, String paramString2, boolean paramBoolean, String paramString3)
  {
    return this.StarCore.StarCommInterface_FileDownLoad(this, paramString1, paramString2, paramBoolean, paramString3);
  }
  
  public boolean _FileUpLoad(String paramString1, String paramString2, String paramString3, StarBinBufClass paramStarBinBufClass, boolean paramBoolean1, String paramString4, boolean paramBoolean2, String paramString5)
  {
    return this.StarCore.StarCommInterface_FileUpLoad(this, paramString1, paramString2, paramString3, paramStarBinBufClass, paramBoolean1, paramString4, paramBoolean2, paramString5);
  }
  
  public String _FormatRspHeader(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt)
  {
    return this.StarCore.StarCommInterface_FormatRspHeader(this, paramString1, paramString2, paramString3, paramString4, paramInt);
  }
  
  public String _FormatRspHeaderEx(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt, String paramString5)
  {
    return this.StarCore.StarCommInterface_FormatRspHeaderEx(this, paramString1, paramString2, paramString3, paramString4, paramInt, paramString5);
  }
  
  public Object _Get(String paramString)
  {
    return this.StarCore.Common_Get(this, paramString);
  }
  
  public Boolean _GetBool(String paramString)
  {
    return this.StarCore.Common_GetBool(this, paramString);
  }
  
  public Double _GetDouble(String paramString)
  {
    return this.StarCore.Common_GetDouble(this, paramString);
  }
  
  public String _GetIP(StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.StarCommInterface_GetIP(this, paramStarBinBufClass);
  }
  
  public Integer _GetInt(String paramString)
  {
    return this.StarCore.Common_GetInt(this, paramString);
  }
  
  public int _GetPort(StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.StarCommInterface_GetPort(this, paramStarBinBufClass);
  }
  
  public boolean _GetResponseBody(StarBinBufClass paramStarBinBufClass1, StarBinBufClass paramStarBinBufClass2)
  {
    return this.StarCore.StarCommInterface_GetResponseBody(this, paramStarBinBufClass1, paramStarBinBufClass2);
  }
  
  public Object[] _GetResponseCode(StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.StarCommInterface_GetResponseCode(this, paramStarBinBufClass);
  }
  
  public int _GetResponseLength(StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.StarCommInterface_GetResponseLength(this, paramStarBinBufClass);
  }
  
  public String _GetResponseStr(StarBinBufClass paramStarBinBufClass, String paramString)
  {
    return this.StarCore.StarCommInterface_GetResponseStr(this, paramStarBinBufClass, paramString);
  }
  
  public String _GetStr(String paramString)
  {
    return this.StarCore.Common_GetStr(this, paramString);
  }
  
  public boolean _Getbool(String paramString)
  {
    return this.StarCore.Common_Getbool(this, paramString);
  }
  
  public double _Getdouble(String paramString)
  {
    return this.StarCore.Common_Getdouble(this, paramString);
  }
  
  public int _Getint(String paramString)
  {
    return this.StarCore.Common_Getint(this, paramString);
  }
  
  public void _HttpClearCookie(String paramString1, String paramString2, String paramString3)
  {
    this.StarCore.StarCommInterface_HttpClearCookie(this, paramString1, paramString2, paramString3);
  }
  
  public int _HttpDownLoad(String paramString1, String paramString2)
  {
    return this.StarCore.StarCommInterface_HttpDownLoad(this, paramString1, paramString2);
  }
  
  public int _HttpDownLoadEx(String paramString1, String paramString2, String paramString3)
  {
    return this.StarCore.StarCommInterface_HttpDownLoadEx(this, paramString1, paramString2, paramString3);
  }
  
  public String _HttpGetHeaderItem(String paramString1, int paramInt, String paramString2)
  {
    return this.StarCore.StarCommInterface_HttpGetHeaderItem(this, paramString1, paramInt, paramString2);
  }
  
  public String _HttpGetHeaderSubItem(String paramString1, int paramInt, String paramString2)
  {
    return this.StarCore.StarCommInterface_HttpGetHeaderSubItem(this, paramString1, paramInt, paramString2);
  }
  
  public String _HttpGetMediaType(String paramString)
  {
    return this.StarCore.StarCommInterface_HttpGetMediaType(this, paramString);
  }
  
  public Object[] _HttpGetMultiPart(StarBinBufClass paramStarBinBufClass1, int paramInt1, int paramInt2, StarBinBufClass paramStarBinBufClass2)
  {
    return this.StarCore.StarCommInterface_HttpGetMultiPart(this, paramStarBinBufClass1, paramInt1, paramInt2, paramStarBinBufClass2);
  }
  
  public String _HttpGetNVValue(String paramString1, String paramString2)
  {
    return this.StarCore.StarCommInterface_HttpGetNVValue(this, paramString1, paramString2);
  }
  
  public int _HttpLocalRequest(int paramInt, String paramString1, String paramString2, String paramString3, StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.StarCommInterface_HttpLocalRequest(this, paramInt, paramString1, paramString2, paramString3, paramStarBinBufClass);
  }
  
  public int _HttpLocalRequestEx(String paramString)
  {
    return this.StarCore.StarCommInterface_HttpLocalRequestEx(this, paramString);
  }
  
  public int _HttpRecv(int paramInt1, StarBinBufClass paramStarBinBufClass, int paramInt2)
  {
    return this.StarCore.StarCommInterface_HttpRecv(this, paramInt1, paramStarBinBufClass, paramInt2);
  }
  
  public void _HttpRelease(int paramInt)
  {
    this.StarCore.StarCommInterface_HttpRelease(this, paramInt);
  }
  
  public int _HttpSend(int paramInt1, StarBinBufClass paramStarBinBufClass, int paramInt2, boolean paramBoolean)
  {
    return this.StarCore.StarCommInterface_HttpSend(this, paramInt1, paramStarBinBufClass, paramInt2, paramBoolean);
  }
  
  public int _HttpServer(String paramString, int paramInt1, int paramInt2)
  {
    return this.StarCore.StarCommInterface_HttpServer(this, paramString, paramInt1, paramInt2);
  }
  
  public void _HttpSetCookie(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
  {
    this.StarCore.StarCommInterface_HttpSetCookie(this, paramString1, paramString2, paramString3, paramBoolean);
  }
  
  public void _HttpSetMaxPostSize(int paramInt1, int paramInt2)
  {
    this.StarCore.StarCommInterface_HttpSetMaxPostSize(this, paramInt1, paramInt2);
  }
  
  public StarTimeClass _HttpTimeToTime(String paramString)
  {
    return this.StarCore.StarCommInterface_HttpTimeToTime(this, paramString);
  }
  
  public int _HttpUpLoad(String paramString1, String paramString2, int paramInt, String paramString3, boolean paramBoolean, String paramString4)
  {
    return this.StarCore.StarCommInterface_HttpUpLoad(this, paramString1, paramString2, paramInt, paramString3, paramBoolean, paramString4);
  }
  
  public int _HttpUpLoadEx(String paramString1, String paramString2, int paramInt, String paramString3)
  {
    return this.StarCore.StarCommInterface_HttpUpLoadEx(this, paramString1, paramString2, paramInt, paramString3);
  }
  
  public boolean _IsHttpConnect(int paramInt)
  {
    return this.StarCore.StarCommInterface_IsHttpConnect(this, paramInt);
  }
  
  public boolean _IsTCPConnect(int paramInt)
  {
    return this.StarCore.StarCommInterface_IsTCPConnect(this, paramInt);
  }
  
  public void _KillTimer(int paramInt)
  {
    this.StarCore.StarCommInterface_KillTimer(this, paramInt);
  }
  
  public String _ParsePara(String paramString1, String paramString2)
  {
    return this.StarCore.StarCommInterface_ParsePara(this, paramString1, paramString2);
  }
  
  public void _Set(String paramString, Object paramObject)
  {
    this.StarCore.Common_Set(this, paramString, paramObject);
  }
  
  public int _SetupTimer(int paramInt1, int paramInt2)
  {
    return this.StarCore.StarCommInterface_SetupTimer(this, paramInt1, paramInt2);
  }
  
  public int _TCPRecv(int paramInt1, StarBinBufClass paramStarBinBufClass, int paramInt2)
  {
    return this.StarCore.StarCommInterface_TCPRecv(this, paramInt1, paramStarBinBufClass, paramInt2);
  }
  
  public int _TCPRecvLine(int paramInt, StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.StarCommInterface_TCPRecvLine(this, paramInt, paramStarBinBufClass);
  }
  
  public void _TCPRelease(int paramInt)
  {
    this.StarCore.StarCommInterface_TCPRelease(this, paramInt);
  }
  
  public int _TCPSend(int paramInt1, StarBinBufClass paramStarBinBufClass, int paramInt2, boolean paramBoolean)
  {
    return this.StarCore.StarCommInterface_TCPSend(this, paramInt1, paramStarBinBufClass, paramInt2, paramBoolean);
  }
  
  public int _TCPSetupClient(int paramInt1, String paramString, int paramInt2)
  {
    return this.StarCore.StarCommInterface_TCPSetupClient(this, paramInt1, paramString, paramInt2);
  }
  
  public int _TCPSetupServer(int paramInt1, String paramString, int paramInt2)
  {
    return this.StarCore.StarCommInterface_TCPSetupServer(this, paramInt1, paramString, paramInt2);
  }
  
  public String _TimeToHttpTime(StarTimeClass paramStarTimeClass)
  {
    return this.StarCore.StarCommInterface_TimeToHttpTime(this, paramStarTimeClass);
  }
  
  public boolean _Tobool(Object paramObject)
  {
    return this.StarCore.Common_Tobool(this, paramObject);
  }
  
  public double _Todouble(Object paramObject)
  {
    return this.StarCore.Common_Todouble(this, paramObject);
  }
  
  public int _Toint(Object paramObject)
  {
    return this.StarCore.Common_Toint(this, paramObject);
  }
  
  public int _UDPRecv(int paramInt, StarBinBufClass paramStarBinBufClass1, StarBinBufClass paramStarBinBufClass2)
  {
    return this.StarCore.StarCommInterface_UDPRecv(this, paramInt, paramStarBinBufClass1, paramStarBinBufClass2);
  }
  
  public void _UDPRelease(int paramInt)
  {
    this.StarCore.StarCommInterface_UDPRelease(this, paramInt);
  }
  
  public int _UDPSend(int paramInt, StarBinBufClass paramStarBinBufClass1, StarBinBufClass paramStarBinBufClass2)
  {
    return this.StarCore.StarCommInterface_UDPSend(this, paramInt, paramStarBinBufClass1, paramStarBinBufClass2);
  }
  
  public boolean _UDPSetSockAddr(String paramString, int paramInt, StarBinBufClass paramStarBinBufClass)
  {
    return this.StarCore.StarCommInterface_UDPSetSockAddr(this, paramString, paramInt, paramStarBinBufClass);
  }
  
  public int _UDPSetupClient(int paramInt)
  {
    return this.StarCore.StarCommInterface_UDPSetupClient(this, paramInt);
  }
  
  public int _UDPSetupServer(int paramInt1, String paramString, int paramInt2)
  {
    return this.StarCore.StarCommInterface_UDPSetupServer(this, paramInt1, paramString, paramInt2);
  }
  
  public void _WebServerRelease(int paramInt)
  {
    this.StarCore.StarCommInterface_WebServerRelease(this, paramInt);
  }
  
  protected void finalize()
  {
    this.StarCore._TermObject(this);
  }
  
  public String toString()
  {
    return this.StarCore.Common_toString(this);
  }
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srplab/www/starcore/StarCommInterfaceClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */