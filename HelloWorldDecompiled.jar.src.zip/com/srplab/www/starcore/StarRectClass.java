package com.srplab.www.starcore;

public class StarRectClass
{
  int bottom;
  int left;
  int right;
  int top;
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srplab/www/starcore/StarRectClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */