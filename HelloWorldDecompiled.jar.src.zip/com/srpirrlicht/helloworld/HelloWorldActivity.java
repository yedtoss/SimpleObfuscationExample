package com.srpirrlicht.helloworld;

import android.app.Activity;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import com.srplab.www.starcore.StarCoreFactoryPath;

public class HelloWorldActivity
  extends Activity
{
  private GLSurfaceView mGLView;
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    StarCoreFactoryPath.InitDefault(Runtime.getRuntime(), "/data/data/com.srpirrlicht.helloworld");
    paramBundle = getAssets();
    this.mGLView = new GLESRenderView(this, getApplication(), paramBundle);
    setContentView(this.mGLView);
  }
  
  protected void onPause()
  {
    System.exit(0);
  }
  
  protected void onResume()
  {
    super.onResume();
    this.mGLView.onResume();
  }
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srpirrlicht/helloworld/HelloWorldActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */