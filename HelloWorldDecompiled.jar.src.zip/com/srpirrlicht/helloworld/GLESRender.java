package com.srpirrlicht.helloworld;

import android.app.Application;
import android.content.res.AssetManager;
import android.opengl.GLSurfaceView.Renderer;
import com.srplab.www.starcore.StarBinBufClass;
import com.srplab.www.starcore.StarCoreFactory;
import com.srplab.www.starcore.StarCoreFactoryPath;
import com.srplab.www.starcore.StarObjectClass;
import com.srplab.www.starcore.StarServiceClass;
import com.srplab.www.starcore.StarSrvGroupClass;
import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class GLESRender
  implements GLSurfaceView.Renderer
{
  boolean AndroidVersion;
  StarObjectClass Cam;
  StarObjectClass Device = null;
  boolean InitFlag;
  Application MyApplication;
  StarObjectClass Node;
  GLESRenderView RenderView;
  StarObjectClass SceneManager;
  StarServiceClass Service;
  String ServicePath;
  StarSrvGroupClass SrvGroup;
  StarObjectClass Texture1;
  StarObjectClass VDiskDrive;
  StarObjectClass VideoDriver;
  AssetManager assetManager;
  StarCoreFactory starcore;
  
  public GLESRender(GLESRenderView paramGLESRenderView, Application paramApplication, AssetManager paramAssetManager)
  {
    this.RenderView = paramGLESRenderView;
    this.MyApplication = paramApplication;
    this.assetManager = paramAssetManager;
    this.InitFlag = false;
    this.AndroidVersion = false;
    if (!this.AndroidVersion)
    {
      this.ServicePath = "";
      return;
    }
    if (StarCoreFactoryPath.StarCoreOperationPath != null)
    {
      this.ServicePath = (StarCoreFactoryPath.StarCoreOperationPath + "/");
      return;
    }
    this.ServicePath = "";
  }
  
  private void InitGame()
  {
    this.VDiskDrive = this.Service._GetObject("DriveClass")._New(new Object[] { "VDisk" })._Assign(new StarObjectClass()
    {
      public Object[] OnRead(StarObjectClass paramAnonymousStarObjectClass, Hashtable paramAnonymousHashtable, String paramAnonymousString, Object paramAnonymousObject)
      {
        paramAnonymousStarObjectClass = new byte['Ѐ'];
        try
        {
          paramAnonymousHashtable = GLESRender.this.assetManager.open(paramAnonymousString);
          for (;;)
          {
            int i = paramAnonymousHashtable.read(paramAnonymousStarObjectClass);
            if (i == -1) {
              break;
            }
            ((StarBinBufClass)paramAnonymousObject)._Write(((StarBinBufClass)paramAnonymousObject)._Getint("_Offset"), paramAnonymousStarObjectClass, i);
          }
          return null;
        }
        catch (IOException paramAnonymousStarObjectClass) {}
      }
    });
    this.VDiskDrive._Call("Lua_LoadWebFile", new Object[] { "sydney.bmp", "sydney.bmp", "", "", "" });
    this.VDiskDrive._Call("Lua_LoadWebFile", new Object[] { "sydney.md2", "sydney.md2", "", "", "" });
    this.SceneManager = ((StarObjectClass)this.Device._Call("Lua_GetSceneManager", new Object[0]));
    this.VideoDriver = ((StarObjectClass)this.Device._Call("Lua_GetVideoDriver", new Object[0]));
    this.Texture1 = this.Service._GetObject("IrrTextureClass")._New(new Object[0]);
    this.Texture1._Set("TextureFile", "VDisk:\\sydney.bmp");
    this.Texture1._Active();
    this.Node = this.Service._GetObject("IrrAnimatedMeshSceneNodeClass")._New(new Object[] { this.SceneManager });
    this.Node._Set("MeshFile", "VDisk:\\sydney.md2");
    this.Node._Set("MD2AnimationType", this.Service._Get("IRREMAT_STAND"));
    this.Node._Active();
    this.Node._Call("Lua_SetMaterialFlag", new Object[] { this.Service._Get("IRREMF_LIGHTING"), Boolean.valueOf(false) });
    this.Node._Call("Lua_SetMaterialTexture", new Object[] { Integer.valueOf(0), this.Texture1 });
    this.Cam = this.Service._GetObject("IrrCameraSceneNodeClass")._New(new Object[] { this.SceneManager });
    this.Cam._Set("Position", new Object[] { Integer.valueOf(0), Integer.valueOf(30), Integer.valueOf(-40) });
    this.Cam._Set("Target", new Object[] { Integer.valueOf(0), Integer.valueOf(15), Integer.valueOf(0) });
    this.Cam._Active();
  }
  
  public void DispatchStarCoreMsg()
  {
    while ((this.AndroidVersion) && (this.starcore._SRPDispatch(false))) {}
  }
  
  public int GetRenderWnd()
  {
    return 0;
  }
  
  public void SetDeviceTimer()
  {
    if (!this.AndroidVersion) {
      this.Device._SetTimer(1, "TimerProc", 0, 0);
    }
  }
  
  public void onDrawFrame(GL10 paramGL10)
  {
    if (this.Device == null) {
      return;
    }
    this.Device._Call("Lua_Render", new Object[0]);
    DispatchStarCoreMsg();
  }
  
  void onPause()
  {
    this.Device._Call("Pause", new Object[0]);
  }
  
  void onResume() {}
  
  public void onSurfaceChanged(GL10 paramGL10, int paramInt1, int paramInt2)
  {
    this.Device._Call("Lua_SetSize", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
  }
  
  public void onSurfaceCreated(GL10 paramGL10, EGLConfig paramEGLConfig)
  {
    if (this.InitFlag)
    {
      this.Device._Call("Resume", new Object[0]);
      return;
    }
    this.InitFlag = true;
    this.starcore = StarCoreFactory.GetFactory();
    this.SrvGroup = this.starcore._GetSrvGroup(Integer.valueOf(0));
    try
    {
      paramGL10 = this.assetManager.open("SRPFSEngine.xml");
      paramEGLConfig = new byte[paramGL10.available()];
      paramGL10.read(paramEGLConfig);
      paramGL10.close();
      paramGL10 = new String(paramEGLConfig);
      this.SrvGroup._ImportServiceFromXmlBuf(paramGL10, true);
      paramGL10 = this.assetManager.open("SRPIrrlichtES2Engine.xml");
      paramEGLConfig = new byte[paramGL10.available()];
      paramGL10.read(paramEGLConfig);
      paramGL10.close();
      paramGL10 = new String(paramEGLConfig);
      this.SrvGroup._ImportServiceFromXmlBuf(paramGL10, true);
      this.SrvGroup._CreateService("", "RemoteCallServer", "123", 5, 0, 0, 0, 0, 0, "");
      this.Service = this.SrvGroup._GetService("root", "123");
      this.Device = this.Service._GetObject("IrrDeviceClass")._New(new Object[0])._Assign(new StarObjectClass()
      {
        public void TimerProc(StarObjectClass paramAnonymousStarObjectClass, int paramAnonymousInt1, int paramAnonymousInt2, int paramAnonymousInt3)
        {
          GLESRender.this.onDrawFrame(null);
        }
      });
      this.Device._Set("Width", Integer.valueOf(800));
      this.Device._Set("Height", Integer.valueOf(480));
      this.Device._Set("RenderWnd", Integer.valueOf(GetRenderWnd()));
      this.Device._Set("Color", Integer.valueOf(255));
      SetDeviceTimer();
      this.Device._Active();
      InitGame();
      return;
    }
    catch (IOException paramGL10)
    {
      for (;;) {}
    }
  }
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srpirrlicht/helloworld/GLESRender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */