package com.srpirrlicht.helloworld;

import android.app.Application;
import android.content.Context;
import android.content.res.AssetManager;
import android.opengl.GLSurfaceView;

class GLESRenderView
  extends GLSurfaceView
{
  GLESRender _renderer;
  
  public GLESRenderView(Context paramContext, Application paramApplication, AssetManager paramAssetManager)
  {
    super(paramContext);
    setEGLContextClientVersion(2);
    this._renderer = new GLESRender(this, paramApplication, paramAssetManager);
    setRenderer(this._renderer);
    setRenderMode(1);
  }
  
  public void onPause()
  {
    super.onPause();
    queueEvent(new Runnable()
    {
      public void run()
      {
        GLESRenderView.this._renderer.onPause();
      }
    });
  }
  
  public void onResume()
  {
    super.onResume();
    queueEvent(new Runnable()
    {
      public void run()
      {
        GLESRenderView.this._renderer.onResume();
      }
    });
  }
}


/* Location:              /Users/yedtoss/Documents/dex2jar-2.0/hello_ori.jar!/com/srpirrlicht/helloworld/GLESRenderView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */